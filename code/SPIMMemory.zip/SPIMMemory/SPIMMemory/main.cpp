//
//  main.cpp
//  SPIMMemory
//
//  Created by Samuel Epstein on 3/27/24.
//

#include <iostream>
#include "MemoryModel.hpp"

int main(int argc, const char * argv[]) {

    MemoryModel mem;
    mem.init(0, 1000);
    int p1 = mem.requestMemoryArray(100);
    int p2 = mem.requestMemoryArray(100);
    int p3 = mem.requestMemoryArray(100);
    int p4 = mem.requestMemoryArray(100);
    int p5 = mem.requestMemoryArray(100);
    //mem.deleteMemoryArray(p2);
    mem.deleteMemoryArray(p4);
    mem.debug_print();
    std::cout << "Delete\n";
    mem.deleteMemoryArray(p3);
    mem.debug_print();
    mem.deleteMemoryArray(p1);
    mem.deleteMemoryArray(p2);
    mem.deleteMemoryArray(p5);
    std::cout << "Empty\n";
    mem.debug_print();
    bool result = mem.requestMemoryArray(2000);
    std::cout << "result:"<<result<<"\n";
    return 0;
}
