//
//  MemoryModel.hpp
//  SPIMMemory
//
//  Created by Samuel Epstein on 3/27/24.
//

#include <stdio.h>
#include <list>
#include <iostream>
#ifndef MemoryModel_hpp
#define MemoryModel_hpp




class MemoryArea
{
public:
    int startAddress=0;
    int endAddress=0;
    bool isEmpty=true;

    int numBytes() {return endAddress-startAddress;}
    MemoryArea();
    MemoryArea(int startAddress, int endAddress, bool isEmpty);
    std::string toString();  
};

class MemoryModel : public std::list<MemoryArea> {
private:
    int startDynamicDataAddress;
    int stopDynamicDataAddress;
    int32_t* memory;
    int16_t* halfMemory;
    int8_t* byteMemory;
    std::list<MemoryArea> memorySegments;
    
public:
    MemoryModel();
    ~MemoryModel();
    void init(int startDynamicDataAddess, int stopDynamicDataAddress);
    bool deleteMemoryArray(int address);
    int requestMemoryArray(int numBytes);
    void debug_print();
    int32_t readWord(int address);
    int32_t readHalf(int address);
    int32_t readByte(int address);
    bool setWord(int address, int value);
    bool setHalf(int address, int value);
    bool setByte(int address, int value);
};

#endif /* MemoryModel_hpp */
