//
//  MemoryModel.cpp
//  SPIMMemory
//
//  Created by Samuel Epstein on 3/27/24.
//

#include "MemoryModel.hpp"


MemoryArea::MemoryArea(){}

MemoryArea::MemoryArea(int startAddress, int endAddress, bool isEmpty) :
startAddress(startAddress), endAddress(endAddress), isEmpty(isEmpty) {
}

std::string MemoryArea::toString() {
    std::string s = "(";
    s.append(std::to_string(startAddress));
    s.append(", ");
    s.append(std::to_string(endAddress));
    s.append(", ");
    s.append((isEmpty ? "Empty" : "Not Empty"));
    s.append(")");
    return s;
}

MemoryModel::MemoryModel(){
    startDynamicDataAddress = 0;
    stopDynamicDataAddress = 0;
    memory = 0;
    halfMemory = 0;
    byteMemory = 0;
}

MemoryModel::~MemoryModel() {
    if(memory!=0)
        free(memory);
}

void MemoryModel::init(int startDynamicDataAddess, int stopDynamicDataAddress){
    this->startDynamicDataAddress = startDynamicDataAddess;
    this->stopDynamicDataAddress = stopDynamicDataAddress;
    memory = (int32_t*)malloc((stopDynamicDataAddress-startDynamicDataAddress));
    halfMemory = (int16_t*)memory;
    byteMemory = (int8_t*)memory;
    
    for(int* i=memory; i<memory+stopDynamicDataAddress-startDynamicDataAddress; i++)
        *i = 0;
    
    memorySegments.push_back(MemoryArea(startDynamicDataAddress,stopDynamicDataAddress,true));
}

bool MemoryModel::deleteMemoryArray(int address){
    std::list<MemoryArea>::iterator itr = memorySegments.begin();
    while(itr != memorySegments.end()){
        if((*itr).startAddress==address)
            break;
        itr++;
    }
    if(itr == memorySegments.end())
        return false;
    if((*itr).isEmpty)
        return false;
    
    if(itr == memorySegments.begin()) {
        if(++itr == memorySegments.end()) {
            memorySegments.clear();
            memorySegments.push_back(MemoryArea(startDynamicDataAddress,stopDynamicDataAddress,true));
            return true;
        }
        if((*itr).isEmpty) {
            memorySegments.erase(memorySegments.begin());
            itr = memorySegments.begin();
            (*itr).startAddress = startDynamicDataAddress;
        } else {
            itr =memorySegments.begin();
            (*itr).isEmpty = true;
        }
        return true;
    }
    else {
        (*itr).isEmpty = true;
    }
    itr--;
    if((*itr).isEmpty){
        int address = (*itr).startAddress;
        itr = memorySegments.erase(itr);
        (*itr).startAddress= address;
    }
    else {
        itr++;
    }
    
    if(++itr == memorySegments.end())
        return true;
    
    if((*itr).isEmpty == true) {
        int address = (*(--itr)).startAddress;
        itr = memorySegments.erase(itr);
        (*itr).startAddress = address;
        return true;
    }
    
    return false;
}

int32_t MemoryModel::requestMemoryArray(int numBytes) {
    list<MemoryArea>::iterator itr = memorySegments.begin();
    for( ; itr != memorySegments.end(); itr++){
        if((*itr).isEmpty && numBytes <= (*itr).numBytes())
            break;
    }
    if(itr == memorySegments.end())
        return 0;
    
    if((*itr).numBytes() == numBytes){
        (*itr).isEmpty = false;
        return (*itr).startAddress;
    }
    MemoryArea ma = MemoryArea((*itr).startAddress, (*itr).startAddress+numBytes, false);
    (*itr).startAddress = ma.endAddress;
    memorySegments.insert(itr, ma);
    return ma.startAddress;
}

void MemoryModel::debug_print() {
    for(list<MemoryArea>::iterator itr = memorySegments.begin(); itr != memorySegments.end(); itr++) {
        std::cout << (*itr).toString() << "\n";
    }
}

int32_t MemoryModel::readWord(int address) {
    if(memory==0)
        return 0;
    return memory[(address-startDynamicDataAddress)>>2];
}
int32_t MemoryModel::readHalf(int address){
    if(memory==0)
        return 0;
    return halfMemory[(address-startDynamicDataAddress)>>1];
}
int32_t MemoryModel::readByte(int address){
    if(memory==0)
        return 0;
    return byteMemory[(address-startDynamicDataAddress)];
}

bool MemoryModel::setWord(int address, int value){
    if(memory==0)
        return false;
    memory[address-startDynamicDataAddress] = value;
    return true;
}
bool MemoryModel::setHalf(int address, int value) {
    if(memory==0)
        return false;
    halfMemory[(address-startDynamicDataAddress)>>1]=(int16_t)value;
    return true;
}
bool MemoryModel::setByte(int address, int value) {
    if(memory==0)
        return false;
    byteMemory[address-startDynamicDataAddress]=(int8_t)value;
    return true;
}
