//
//  JPDatum.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/11/24.
//

#include "JPDatum.hpp"


JPDatum::JPDatum() : JPDatum(Var,-1,0,0){}

//JPDatum::JPDatum(DatType datType,int reg, long execCount, int value) : JPDatum(datType, reg, execCount, value, Regular)
//{}

JPDatum::JPDatum(DatType datType, int reg, long execCount, int value) :
    datType(datType),
    reg(reg),
    execCount(execCount), 
    value(value),
    unknownValue(false)
 //   sourceType(sourceType)
{
}

string JPDatum::ToString()
{
    if(datType==Const && reg==0 && value==0)
        return "<0>";
    
    string s = "(";
    s.append(to_string(execCount));
    switch(datType)
    {
        case Var:
            s.append(", Var, $");
            break;
        case StackVar:
            s.append(", StackVar, $");
            break;
        case Const:
            s.append(", Const, $");
            break;
        default:
            break;
    }
    s.append(to_string(reg));
    s.append(", ");
    s.append(to_string(value));
    s.append(")");

    return s;
}
