//
//  JPConstReconcile.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/15/24.
//

#ifndef JPConstReconcile_hpp
#define JPConstReconcile_hpp

#include "JPExp.hpp"
#include"JPDatum.hpp"
#include <map>
#include <set>

#include <stdio.h>

using namespace std;

class JPConstReconcile
{
private:
    
    map<JPDatum*,set<JPAddSubExp*>*> addSubExpLookup;
    set<JPDatum*> constSet;
    set<JPAddSubExp*> allVarsAddSubExp;
  
    void AddAddSubExpLookup(JPDatum* dat, JPAddSubExp *exp);
    
public:
    JPConstReconcile(){}
    ~JPConstReconcile();
    
    void ReconcileConstDatums();
    void AddConstDatum(JPDatum* dat){constSet.insert(dat);}
    void AddExp(JPExp *exp);
    
};
#endif /* JPConstReconcile_hpp */
