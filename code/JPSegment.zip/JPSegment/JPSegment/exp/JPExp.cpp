//
//  JPExp.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/11/24.
//

#include "JPExp.hpp"


JPExp::JPExp() : JPExp(0,0) {}

JPExp::JPExp(long pc, long execCount) : pc(pc), execCount(execCount) 
{
}

string JPExp::ToString()
{
    return "";
}





JPFreeExp::JPFreeExp() : JPFreeExp(0,0,0) {}

JPFreeExp::JPFreeExp(long pc, long execCount, JPDatum* dat) : JPExp(pc,execCount), dat(dat) {}

string JPFreeExp::ToString()
{
    string s = "(FreeExp, ";
    
    s.append(to_string(pc));
    s.append(", ");
    s.append(to_string(execCount));
    s.append(", ");

    if(dat == 0)
    {
        s.append("NULL)");
        return s;
    }
    
    s.append(dat->ToString());
    s.append(")");
    return s;
    
        return ",NULL)";
    
}


JPMallocExp::JPMallocExp(){}
JPMallocExp::JPMallocExp(long pc, long execCount, JPDatum* srcDat, JPDatum* destDat) : JPExp(pc, execCount), srcDat(srcDat), destDat(destDat)
{}

string JPMallocExp::ToString()
{
    string s = "(MallocExp, ";
    
    s.append(to_string(pc));
    s.append(", ");
    s.append(to_string(execCount));
    s.append(", ");

    
    if(srcDat==0)
        s.append("NULL, ");
    else
    {
        s.append(srcDat->ToString());
        s.append(", ");
    }
    
    if(destDat==0)
        s.append("NULL)");
    else
    {
        s.append(destDat->ToString());
        s.append(")");
    }
    return s;
}

JPAddSubExp::JPAddSubExp() : JPAddSubExp(0,0,0,0,0,true) {}

JPAddSubExp::JPAddSubExp(long pc, long execCount, JPDatum* destDat, JPDatum* src1Dat, JPDatum* src2Dat, bool isAdd) : JPExp(pc,execCount), destDat(destDat), src1Dat(src1Dat), src2Dat(src2Dat), isAdd(isAdd) {}

string JPAddSubExp::ToString()
{
    string s = "(AddSubExp, ";
    s.append(to_string(pc));
    s.append(", ");
    s.append(to_string(execCount));
    s.append(", ");
    if(isAdd)
    {
        s.append("Add, ");
    }
    else
    {
        s.append("Sub, ");
    }
    if(src1Dat==0)
    {
        s.append("NULL, ");
    }
    else
    {
        s.append(src1Dat->ToString());
        s.append(", ");
    }
    
    if(src2Dat==0)
    {
        s.append("NULL, ");
    }
    else
    {
        s.append(src2Dat->ToString());
        s.append(", ");
    }
    
    if(destDat==0)
    {
        s.append("NULL");
    }
    else
    {
        s.append(destDat->ToString());
    }
    s.append(")");
    return s;
}

JPDatum* JPAddSubExp::GetSourceVar()
{
    if(this->src1Dat->datType==Const && this->src2Dat->datType == Const)
        throw new Exception("JPAddSubExp: cannot have two const sources.");

    if(this->src1Dat->datType!=Const && this->src2Dat->datType != Const)
        throw new Exception("JPAddSubExp: cannot have two non-const sources.");
    
    if(this->src1Dat->datType!=Const)
        return src1Dat;
    return src2Dat;
}

int JPAddSubExp::GetConstOffset()
{
    if(this->src1Dat->datType==Const && this->src2Dat->datType == Const)
        throw new Exception("JPAddSubExp: cannot have two const sources.");

    if(this->src1Dat->datType!=Const && this->src2Dat->datType != Const)
        throw new Exception("JPAddSubExp: cannot have two non-const sources.");
    
    if(this->src1Dat->datType==Const)
        return this->src1Dat->value;
    
    return this->src2Dat->value;
}

bool JPAddSubExp::IsAllConstant()
{
    if(this->src1Dat==nullptr
       || this->src2Dat==nullptr
       || this->destDat==nullptr)
        throw new Exception("JPAddSub has nullptr dats");
    
    return this->src1Dat->datType==Const && this->src2Dat->datType==Const && this->destDat->datType==Const;
}

bool JPAddSubExp::IsAllVars()
{
    if(this->src1Dat==nullptr
       || this->src2Dat==nullptr
       || this->destDat==nullptr)
        throw new Exception("JPAddSub has nullptr dats");
   
    return this->src1Dat->datType==Var && this->src2Dat->datType==Var && this->destDat->datType==Var;

}

JPSWExp::JPSWExp() : JPSWExp(0,0,0,0,0) {}

JPSWExp::JPSWExp(long pc, long execCount, JPDatum* destDat, JPDatum* srcDat, int offset) : JPExp(pc,execCount), destDat(destDat), srcDat(srcDat), offset(offset)
{
    
}

string JPSWExp::ToString()
{
    string s = "(SWExp, ";
    s.append(to_string(pc));
    s.append(", ");
    s.append(to_string(execCount));
    s.append(", ");
    
    if(srcDat==0)
    {
        s.append("NULL, ");
    }
    else
    {
        s.append(srcDat->ToString());
        s.append(", ");
    }
    
    if(destDat==0)
    {
        s.append("NULL, ");
    }
    else
    {
        s.append(destDat->ToString());
        s.append(", ");
    }
    
    s.append(to_string(offset));
    s.append(")");
    return s;
}



JPLWExp::JPLWExp() : JPLWExp(0,0,0,0,0) {}

JPLWExp::JPLWExp(long pc, long execCount, JPDatum* destDat, JPDatum* srcDat, int offset) : JPExp(pc,execCount), destDat(destDat), srcDat(srcDat), offset(offset)
{
    
}

string JPLWExp::ToString()
{
    string s = "(LWExp, ";
    s.append(to_string(pc));
    s.append(", ");
    s.append(to_string(execCount));
    s.append(", ");
    
    if(srcDat==0)
    {
        s.append("NULL, ");
    }
    else
    {
        s.append(srcDat->ToString());
        s.append(", ");
    }
    
    if(destDat==0)
    {
        s.append("NULL, ");
    }
    else
    {
        s.append(destDat->ToString());
        s.append(", ");
    }
    
    s.append(to_string(offset));
    s.append(")");
    return s;
}
