//
//  JPExpList.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/11/24.
//

#ifndef JPExpList_hpp
#define JPExpList_hpp

#define HI_REG -10
#define LO_REG -20

#include <list>
#include <set>
#include <map>
#include <stdio.h>
#include <iostream>
#include "exception.h"

using namespace std;


#include "JPConstReconcile.hpp"
#include "JPExp.hpp"
#include "JPDatum.hpp"
#include "JPStack.hpp"

class JPExpList
{
private:
    
    list<JPExp*> exps;
    set<JPDatum*> initRegDatums;
    map<int,JPDatum*> latestDatum;
    
    set<JPDatum*> allDatums;
    
    JPStack stack;
    JPConstReconcile constReconcile;
    
public:
    
    JPExpList(){}
    ~JPExpList();
    
    list<JPExp*>::iterator ExpsBegin(){return exps.begin();}
    list<JPExp*>::iterator ExpsEnd(){return exps.end();}
    
    set<JPDatum*>::iterator InitRegDatumsBegin(){return initRegDatums.begin();}
    set<JPDatum*>::iterator InitRegDatumsEnd(){return initRegDatums.end();}
    
    map<int,JPDatum*>::iterator LatestDatumBegin(){return latestDatum.begin();}
    map<int,JPDatum*>::iterator LatestDatumEnd(){return latestDatum.end();}

    map<int,JPDatum*>::iterator StackDatumsBegin(){return stack.DatumsBegin();}
    map<int,JPDatum*>::iterator StackDatumsEnd(){return stack.DatumsEnd();}
   
    map<int,JPDatum*>::iterator StackFirstReadDatumsBegin(){return stack.FirstReadDatumsBegin();}
    map<int,JPDatum*>::iterator StackFirstReadDatumsEnd(){return stack.FirstReadDatumsEnd();}
   
    
    JPDatum* GetLatestDatum(int reg);
    JPDatum* GetOrCreateLatestDatum(int reg, long execCount, int val, bool forceConst);
    void PushBackExp(JPExp* exp);
    void SetLatestDatum(JPDatum* dat){latestDatum[dat->reg]=dat;}
    void AddDatum(JPDatum* dat){this->allDatums.insert(dat);}
    bool HasLatestDatum(int reg){return this->latestDatum.contains(reg);}
    
    void AddConstDatum(JPDatum* dat){constReconcile.AddConstDatum(dat);}
    void ConstReconcile(){constReconcile.ReconcileConstDatums();}
    
    void SetStackDatum(int offset, JPDatum* datum){stack.SetDatum(offset,datum);}
    JPDatum *GetOrCreateDatumFromStack(int offset, int val){return stack.GetOrCreateDatum(offset,val);}
    
    void DebugPrint();
};

#endif /* JPExpList_hpp */
