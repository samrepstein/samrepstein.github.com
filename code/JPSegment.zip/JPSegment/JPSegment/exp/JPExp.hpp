//
//  JPExp.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/11/24.
//

#ifndef JPExp_hpp
#define JPExp_hpp

#define STACK_POINTER_REG 29
#include <stdio.h>
#include <string>
#include "JPDatum.hpp"
#include "exception.h"

//#include "JPExpList.hpp"

using namespace std;

class JPExp
{
protected:
    long pc;
    long execCount;
public:
    JPExp();
    JPExp(long pc, long execCount);
    
    virtual string ToString();
    long GetPC(){return pc;}
    long GetExecCount(){return execCount;}
    
 };

class JPFreeExp : public JPExp
{
private:
    JPDatum* dat;
    
public:
    JPFreeExp();
    JPFreeExp(long pc, long execCount, JPDatum* dat);
    
    JPDatum* GetDat(){return dat;}
    void SetDat(JPDatum* dat){this->dat=dat;}
    
    virtual string ToString();

};

class JPMallocExp : public JPExp
{
private:
    JPDatum* srcDat;
    JPDatum* destDat;
    
public:
    JPMallocExp();
    JPMallocExp(long pc, long execCount, JPDatum* srcDat, JPDatum* destDat);
    
    JPDatum* GetSrcDat(){return srcDat;}
    JPDatum* GetDestDat(){return destDat;}
    
    void SetSrcDat(JPDatum* srcDat){this->srcDat = srcDat;}
    void SetDestDat(JPDatum* destDat){this->destDat = destDat;}
    
    
    virtual string ToString();

};

class JPAddSubExp : public JPExp
{
private:
    JPDatum* destDat;
    JPDatum* src1Dat;
    JPDatum* src2Dat;
    bool isAdd;
public:
    JPAddSubExp();
    JPAddSubExp(long pc, long execCount, JPDatum* destDat, JPDatum* src1Dat, JPDatum* src2Dat, bool isAdd);
    
    JPDatum* GetDestDat(){return destDat;}
    JPDatum* GetSrc1Dat(){return src1Dat;}
    JPDatum* GetSrc2Dat(){return src2Dat;}
    
    void SetDestDat(JPDatum* destDat){this->destDat = destDat;}
    void SetSrc1Dat(JPDatum* src1Dat){this->src1Dat = src1Dat;}
    void SetSrc2Dat(JPDatum* src2Dat){this->src2Dat = src2Dat;}
    
    bool IsAllConstant();
    bool IsAllVars();
    
    JPDatum* GetSourceVar();
    int GetConstOffset();
    
    virtual string ToString();
    
};

class JPLWExp : public JPExp
{
private:
    JPDatum* destDat;
    JPDatum* srcDat;
    int offset;
public:
    JPLWExp();
    JPLWExp(long pc, long execCount, JPDatum* destDat, JPDatum* srcDat, int offset);
    
    JPDatum* GetDestDat(){return destDat;}
    JPDatum* GetSrcDat(){return srcDat;}
    int GetOffset(){return offset;}
    
    void SetDestDat(JPDatum* destDat){this->destDat = destDat;}
    void SetSrcDat(JPDatum* srcDat){this->srcDat = srcDat;}
    void setOffset(int offset){this->offset=offset;}
    
    virtual string ToString();
    
};

class JPSWExp : public JPExp
{
private:
    JPDatum* destDat;
    JPDatum* srcDat;
    int offset;
public:
    JPSWExp();
    JPSWExp(long pc, long execCount, JPDatum* destDat, JPDatum* srcDat, int offset);

    JPDatum* GetDestDat(){return destDat;}
    JPDatum* GetSrcDat(){return srcDat;}
    int GetOffset(){return offset;}
    
    void SetDestDat(JPDatum* destDat){this->destDat = destDat;}
    void SetSrcDat(JPDatum* srcDat){this->srcDat = srcDat;}
    void setOffset(int offset){this->offset=offset;}
    
    virtual string ToString();

};
#endif /* JPExp_hpp */
