//
//  JPConstReconcile.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/15/24.
//

#include "JPConstReconcile.hpp"

JPConstReconcile::~JPConstReconcile()
{
    for(map<JPDatum*, set<JPAddSubExp*>*>::iterator itr = addSubExpLookup.begin(); itr != addSubExpLookup.end(); itr++)
    {
        free(itr->second);
    }
}

void JPConstReconcile::ReconcileConstDatums()
{
    set<JPDatum*> visitedDats;
    set<JPDatum*> nextRoundDats;
    
    do
    {
        for(set<JPDatum*>::iterator itr = constSet.begin(); itr != constSet.end(); itr++)
        {
            if((*itr)->reg==0)
                continue;
            
            visitedDats.insert((*itr));
            
            (*itr)->datType=Const;
            
            if(!this->addSubExpLookup.contains(*itr))
                continue;
            
            set<JPAddSubExp*>* exps = addSubExpLookup[*itr];
            for(set<JPAddSubExp*>::iterator etr = exps->begin(); etr != exps->end(); etr++)
            {
                if((*etr)->IsAllConstant())
                    continue;
                
                JPDatum *src1 = (*etr)->GetSrc1Dat();
                JPDatum *src2 = (*etr)->GetSrc2Dat();
                JPDatum *dest = (*etr)->GetDestDat();
                
                if((*etr)->GetDestDat()->datType==Const)
                {
                    if(src1->datType==StackVar)
                        throw new Exception("Cannot force StackVar src1 to be Const");
                    
                    if(src1->datType==Var)
                    {
                        src1->datType=Const;
                        if(!visitedDats.contains(src1))
                            nextRoundDats.insert(src1);
                    }
                    
                    if(src2->datType==StackVar)
                        throw new Exception("Cannot force StackVar src2 to be Const");
                    
                    if(src2->datType==Var)
                    {
                        src2->datType=Const;
                        
                        if(!visitedDats.contains(src2))
                            nextRoundDats.insert(src2);
                    }
                    continue;
                }
                
                if(src1->datType==Const && src2->datType==Const)
                {
                    if(dest->datType==StackVar)
                        throw new Exception("Cannot force StackVar dest to be Const");
                    dest->datType = Const;
                    
                    if(!visitedDats.contains(dest))
                        nextRoundDats.insert(dest);
                }
            }
        }
        
        constSet.clear();
        
        if(nextRoundDats.empty())
        {
            if(this->allVarsAddSubExp.empty())
                break;
            
            for(set<JPAddSubExp*>::iterator itr = this->allVarsAddSubExp.begin(); itr != allVarsAddSubExp.end(); )
            {
                if(!(*itr)->IsAllVars())
                {
                    itr = allVarsAddSubExp.erase(itr);
                    continue;
                }
                
                JPDatum *destDat = (*itr)->GetDestDat();
                JPDatum *src1Dat = (*itr)->GetSrc1Dat();
                JPDatum *src2Dat = (*itr)->GetSrc2Dat();
                
                destDat->datType=Const;
                src1Dat->datType=Const;
                src2Dat->datType=Const;
                
                if(!visitedDats.contains(destDat))
                    constSet.insert(destDat);
                
                if(!visitedDats.contains(src1Dat))
                    constSet.insert(src1Dat);
                
                if(!visitedDats.contains(src2Dat))
                    constSet.insert(src2Dat);
                break;
            }
        }
        
        constSet.insert(nextRoundDats.begin(), nextRoundDats.end());
        nextRoundDats.clear();

    }while(true);
}

void JPConstReconcile::AddAddSubExpLookup(JPDatum* dat, JPAddSubExp *exp)
{
    if(dat->reg==0)
        return;
    if(addSubExpLookup.contains(dat))
    {
        set<JPAddSubExp*>* set = addSubExpLookup[dat];
        set->insert(exp);
    }
    else
    {
        set<JPAddSubExp*>* set = new std::set<JPAddSubExp*>();
        set->insert(exp);
        addSubExpLookup[dat]=set;
    }
}

void JPConstReconcile::AddExp(JPExp *exp)
{
    JPAddSubExp *asExp = dynamic_cast<JPAddSubExp*>(exp);
    
    if(asExp == nullptr)
        return;
    
    this->AddAddSubExpLookup(asExp->GetDestDat(), asExp);
    this->AddAddSubExpLookup(asExp->GetSrc1Dat(), asExp);
    this->AddAddSubExpLookup(asExp->GetSrc2Dat(), asExp);
    
    if(asExp->IsAllVars())
        this->allVarsAddSubExp.insert(asExp);
}
