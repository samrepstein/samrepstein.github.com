//
//  JPExpList.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/11/24.
//

#include "JPExpList.hpp"


JPExpList::~JPExpList()
{
    
    for(list<JPExp*>::iterator itr = exps.begin(); itr != exps.end(); itr++)
    {
        free(*itr);
    }
    
    for(set<JPDatum*>::iterator itr = allDatums.begin(); itr != allDatums.end(); itr++)
    {
        free(*itr);
    }

    
}

JPDatum* JPExpList::GetLatestDatum(int reg)
{
    if(reg==0)
    {
        throw new Exception("Cannot lookup 0 reg");
    }
    
    if(!latestDatum.contains(reg))
        return 0;
    
    return latestDatum[reg];
}

JPDatum* JPExpList::GetOrCreateLatestDatum(int reg,  long execCount,  int val, bool forceConst)
{
    if(reg==0)
    {
        JPDatum *zeroDat = new JPDatum();
        zeroDat->value=val;
        zeroDat->reg=0;
        zeroDat->datType=Const;
        this->AddDatum(zeroDat);
        return zeroDat;
    }
    if(latestDatum.contains(reg))
    {
        JPDatum *dat = latestDatum[reg];
       
        if(dat->unknownValue)
        {
            dat->value = val;
            dat->unknownValue = false;
        }
        else if(dat->datType==StackVar)
        {
            int tempVal = stack.GetSPOffset(val);
            if(dat->value != tempVal)
            {
                std:string s = "StackVars mismatch: (";
                s.append(to_string(dat->value));
                s.append(", ");
                s.append(to_string(tempVal));
                s.append(")");
                throw new Exception(s);
            }
        }
        else if(dat->value!=val)
        {
            std::string s = "Datum val mismatch:[";
            s.append(dat->ToString());
            s.append(", ");
            s.append(to_string(val));
            s.append("]");
            throw Exception(s);
        }
        if(forceConst && dat->datType==Var)
        {
            this->constReconcile.AddConstDatum(dat);
            dat->datType = Const;
        }
        
        return dat;
    }
    
    JPDatum* dat = new JPDatum();
    dat->execCount = 0;
    dat->reg = reg;
    dat->value = val;
    
    if(dat->reg==STACK_POINTER_REG)
    {
        dat->datType = StackVar;
        stack.SetInitialSPValue(val);
        dat->value = 0;
    }
    else
    {
        dat->datType = forceConst ? Const : Var;
       // dat->sourceType = InitReg;
    }
    
    this->initRegDatums.insert(dat);
    allDatums.insert(dat);
    this->latestDatum[dat->reg]=dat;
    
    return dat;
}

void JPExpList::PushBackExp(JPExp* exp)
{
    this->constReconcile.AddExp(exp);
    exps.push_back(exp);
}

void JPExpList::DebugPrint()
{
    std::cout << "Expressions:\n";
    
    for(list<JPExp*>::iterator itr = this->exps.begin(); itr != this->exps.end(); itr++)
    {
        std::cout << "\t" << (*itr)->ToString() << "\n";
    }
    std::cout << "\n";
    stack.DebugPrint();
    std::cout << "\nInit Registers:\n";
    for(set<JPDatum*>::iterator itr = this->initRegDatums.begin(); itr != this->initRegDatums.end(); itr++)
    {
        std::cout <<"\t"<<(*itr)->ToString()<<"\n";
    }
    std::cout << "\nRegister Lookup:\n";
    for(map<int,JPDatum*>::iterator itr = this->latestDatum.begin(); itr != this->latestDatum.end(); itr++)
    {
        std:cout << "\t" << itr->second->ToString() << "\n";
    }
    std::cout << "\n";
}
