//
//  JPStack.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/14/24.
//

#ifndef JPStack_hpp
#define JPStack_hpp

//#define STACK_REG -30

#include <stdio.h>
#include <map>
#include <iostream>

#include "JPDatum.hpp"
#include "Exception.h"

using namespace std;

class JPStack
{

private:
    
    map<int,JPDatum*> firstReadDatums;
    map<int,JPDatum*> datums;
    //map<int,bool> readFirst;
    int initialSPValue = 0;
    
public:
    JPStack(){}
    
    map<int,JPDatum*>::iterator FirstReadDatumsBegin(){return firstReadDatums.begin();}
    map<int,JPDatum*>::iterator FirstReadDatumsEnd(){return firstReadDatums.end();}
    
    map<int,JPDatum*>::iterator DatumsBegin(){return datums.begin();}
    map<int,JPDatum*>::iterator DatumsEnd(){return datums.end();}
    
    
    void SetInitialSPValue(int initialSPValue){this->initialSPValue=initialSPValue;}
    int GetSPOffset(int sp){return sp - this->initialSPValue;}
    void SetDatum(int offset, JPDatum* datum);
    JPDatum *GetOrCreateDatum(int offset, int val);
    
    void DebugPrint();
};
#endif /* JPStack_hpp */
