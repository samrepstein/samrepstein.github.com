//
//  JPStack.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/14/24.
//

#include "JPStack.hpp"



void JPStack::SetDatum(int offset, JPDatum* datum)
{
    if(datum == nullptr)
        throw new Exception("Cannot add null datum to stack");
    
    //if(!this->readFirst.contains(offset))
    //readFirst[offset]=false;
    
    datums[offset] = datum;
}

JPDatum *JPStack::GetOrCreateDatum(int offset, int val)
{
    if(this->datums.contains(offset))
    {
        JPDatum *dat = datums[offset];
        if(dat == nullptr)
            throw new Exception("Stack has null datum");
        if(dat->value!=val)
            throw new Exception("Stack datum has value mismatch");
        return dat;
    }
    
    //if(!this->readFirst.contains(offset))
    //readFirst[offset]=true;

    JPDatum *dat = new JPDatum(Var, 0, 0, val);
    datums[offset]=dat;
    this->firstReadDatums[offset]=dat;
    return dat;
}

void JPStack::DebugPrint()
{
    std::cout << "Stack:\n";
    for(map<int,JPDatum*>::iterator itr = this->datums.begin(); itr != this->datums.end(); itr++)
    {
        int offset = itr->first;
        JPDatum *dat = itr->second;
        bool readFirst = this->firstReadDatums.contains(offset);
        std::cout << "\t[" << offset << ", " << (readFirst ? "ReadFirst" : "WriteFirst") << "], " << dat->ToString() << "\n";
    }
}
