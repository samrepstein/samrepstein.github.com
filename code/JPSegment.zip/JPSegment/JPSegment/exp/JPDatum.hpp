//
//  JPDatum.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/11/24.
//

#ifndef JPDatum_hpp
#define JPDatum_hpp

#include <stdio.h>
#include <string>

using namespace std;

enum DatType {StackVar,Var,Const};
//enum SourceType {Regular,InitReg,InitStack};

class JPDatum
{
    
public:
    JPDatum();
    JPDatum(DatType datType, int reg, long execCount, int value);
  //  JPDatum(DatType datType, int reg, long execCount, int value, SourceType sourceType);
    
  //  SourceType sourceType;
    DatType datType;
    bool unknownValue;
    int reg;
    long execCount;
    int value;
    
   string ToString();
};
#endif /* JPDatum_hpp */
