//
//  JPRedDatum.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/16/24.
//

#ifndef JPRedDatum_hpp
#define JPRedDatum_hpp

#include <stdio.h>
//#include "exception.h"

#include <string>
#include <stdio.h>

using namespace std;

enum JPRedDatumLocationType {Reg,Stack,FromLW,FromMalloc,RConst};

union AuxSourceData
{
    int reg;
    long execCountSource;
    int stackOffset;
};

class JPRedDatum
{
    
protected:
    
    bool isMarked;
    JPRedDatum *source;
    
    JPRedDatumLocationType locationType;
    AuxSourceData auxData;
    
public:
    JPRedDatum();
    virtual ~JPRedDatum(){}
    void Mark();
    void SetSource(JPRedDatum *source){this->source=source;}

    void SetLocationTypeReg(int reg);
    void SetLocationTypeStackOffset(int stackOffset);
    void SetLocationTypeLWExecCountSource(long execCountSource);
    void SetLocationTypeMallocExecCountSource(long execCountSource);
    void SetLocationType(JPRedDatumLocationType locationType, AuxSourceData auxData);
    void SetLocationTypeRConst(){locationType=RConst;}
    
    JPRedDatumLocationType GetLocationType(){return locationType;}
    AuxSourceData GetAuxData(){return auxData;}
    bool IsMarked(){return isMarked;}
    
    JPRedDatum *GetSource(){return source;}
    
    virtual string ToString();
    
};

class JPRedDConst : public JPRedDatum
{
    
public:
    
    JPRedDConst();
    JPRedDConst(int value);
    int value;
    
    virtual string ToString();
    
 };

class JPRedDVar : public JPRedDatum
{
    
public:
    
    JPRedDVar();
    JPRedDVar(int offset);

    int offset;

    string ToString();
};


#endif /* JPRedDatum_hpp */
