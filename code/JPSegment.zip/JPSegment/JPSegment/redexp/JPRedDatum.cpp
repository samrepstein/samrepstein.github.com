//
//  JPRedDatum.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/16/24.
//

#include "JPRedDatum.hpp"
#include "exception.h"

JPRedDatum::JPRedDatum() : isMarked(false), source(nullptr), locationType(RConst)
{
}


string JPRedDatum::ToString()
{
    string s = "";
    s.append(isMarked ? "Marked, Loc:" : "UnMarked, Loc");
    switch(locationType)
    {
        case Reg:
            s.append("(Reg, ");
            s.append(to_string(auxData.reg));
            s.append(")");
            break;
            
        case Stack:
            s.append("(Stack, ");
            s.append(to_string(auxData.stackOffset));
            s.append(")");
            break;
            
        case FromLW:
            s.append("(FromLW, ");
            s.append(to_string(auxData.execCountSource));
            s.append(")");
            break;
            
        case FromMalloc:
            s.append("(FromMalloc, ");
            s.append(to_string(auxData.execCountSource));
            s.append(")");
            break;
        case RConst:
            s.append("RConst");
            break;
            
        default:
            throw new Exception("Unknown LocationType");
    }

    return s;
}

void JPRedDatum::Mark()
{
    if(isMarked)
        return;
    
    isMarked=true;
    
    if(source != this && source!=nullptr)
        source->Mark();
}

void JPRedDatum::SetLocationTypeReg(int reg)
{
    locationType = Reg;
    this->auxData.reg = reg;
}

void JPRedDatum::SetLocationTypeStackOffset(int stackOffset)
{
    locationType = Stack;
    this->auxData.stackOffset = stackOffset;
}

void JPRedDatum::SetLocationTypeLWExecCountSource(long execCountSource)
{
    locationType = FromLW;
    this->auxData.execCountSource = execCountSource;
}

void JPRedDatum::SetLocationTypeMallocExecCountSource(long execCountSource)
{
    locationType = FromMalloc;
    this->auxData.execCountSource = execCountSource;
}


void JPRedDatum::SetLocationType(JPRedDatumLocationType locationType, AuxSourceData auxData)
{
    this->locationType = locationType;
    this->auxData = auxData;
}



JPRedDConst::JPRedDConst() : value(0) {}
JPRedDConst::JPRedDConst(int value) : JPRedDatum(), value(value) 
{
    locationType = RConst;
}

string JPRedDConst::ToString()
{
    string s = "(";
    s.append(JPRedDatum::ToString());
    s.append(", Const: ");
    s.append(to_string(value));
    s.append(")");
    return s;
}

JPRedDVar::JPRedDVar() : JPRedDVar(0){}
JPRedDVar::JPRedDVar(int offset)
    : JPRedDatum(), offset(offset) {}

string JPRedDVar::ToString()
{
    string s = "(";
    s.append(JPRedDatum::ToString());
    s.append(", Var: ");
    s.append(to_string(offset));
    s.append(")");
    
    return s;
}
