//
//  JPRedExp.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/16/24.
//

#include "JPRedExp.hpp"

JPRedExp::JPRedExp() : JPRedExp(0,0){}

JPRedExp::JPRedExp(long pc, long execCount) : pc(pc), execCount(execCount)
{
}

string JPRedExp::ToString()
{
    string s = "<";
    s.append(to_string(pc));
    s.append(", ");
    s.append(to_string(execCount));
    s.append(">");
    return s;
}

JPRedLWExp::JPRedLWExp() : JPRedLWExp(0,0,0,0)
{
    
}

JPRedLWExp::JPRedLWExp(long pc, long execCount, JPRedDatum *addrDatum, JPRedDatum *destDatum)
    : JPRedExp(pc,execCount), addrDatum(addrDatum), destDatum(destDatum)
{
    
}

string JPRedLWExp::ToString()
{
    string s = "(";
    s.append(JPRedExp::ToString());
    s.append(", RedLWExp, Addr:");
    s.append(this->addrDatum->ToString());
    s.append(", Dest:");
    s.append(this->destDatum->ToString());
    s.append(")");
    return s;
    
}

JPRedSWExp::JPRedSWExp() : JPRedSWExp(0,0,0,0)
{
    
}

string JPRedSWExp::ToString()
{
    
    string s = "(";
    s.append(JPRedExp::ToString());
    s.append(", RedSWExp, Addr:");
    s.append(this->addrDatum->ToString());
    s.append(", Source");
    s.append(this->sourceDatum->ToString());
    s.append(")");
    return s;
}

JPRedSWExp::JPRedSWExp(long pc, long execCount, JPRedDatum *addrDatum, JPRedDatum *sourceDatum)
    : JPRedExp(pc,execCount), addrDatum(addrDatum), sourceDatum(sourceDatum)
{
    
}


JPRedMallocExp::JPRedMallocExp(){}
JPRedMallocExp::JPRedMallocExp(long pc, long execCount, JPRedDConst *argDatum, JPRedDVar *varDatum)
    : JPRedExp(pc, execCount), argDatum(argDatum), varDatum(varDatum)
{
}

string JPRedMallocExp::ToString()
{
    string s = "(";
    s.append(JPRedExp::ToString());
    s.append(", RedMallocExp, Arg:");
    s.append(this->argDatum->ToString());
    s.append(", Var:");
    s.append(this->varDatum->ToString());
    s.append(")");
    return s;
}

JPRedFreeExp::JPRedFreeExp() : JPRedFreeExp(0,0,0) {}

JPRedFreeExp::JPRedFreeExp(long pc, long execCount, JPRedDVar *argDatum)
    : JPRedExp(pc, execCount), argDatum(argDatum)
{
}

string JPRedFreeExp::ToString()
{
    string s = "(";
    s.append(JPRedExp::ToString());
    s.append(", FreeExp, Arg:");
    s.append(this->argDatum->ToString());
    s.append(")");
    return s;
}
