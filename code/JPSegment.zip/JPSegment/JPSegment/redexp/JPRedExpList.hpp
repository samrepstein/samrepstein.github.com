//
//  JPRedExpList.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/16/24.
//

#ifndef JPRedExpList_hpp
#define JPRedExpList_hpp

#include "JPRedDatum.hpp"
#include "JPRedExp.hpp"
#include "JPExpList.hpp"

#include <list>
#include <map>
#include <set>
#include <stdio.h>
using namespace std;

class JPRedExpList
{
private:
    std::list<JPRedExp*> redExps;
    
    std::map<int,JPRedDatum*> initRegs;
    std::map<int,JPRedDatum*> endRegs;
    
    std::map<int,JPRedDatum*> initStack;
    std::map<int,JPRedDatum*> endStack;
    
    std::set<JPRedDatum*> allRedDatums;
    
    int spChange;
    bool isSPtoSP;
    
    
public:
    JPRedExpList();
    virtual ~JPRedExpList();
    
    int GetSPChange(){return spChange;}
    bool IsSPtoSP(){return isSPtoSP;}
    bool UsedSP(){return this->initRegs.contains(STACK_POINTER_REG);}
    void CreateRedExps(JPExpList &list);
  
    bool LookForHangingDatum();
    void RemoveUnmarkedRedDatums();
 
    void KillDeadMemory();
    void DebugPrint();
};
#endif /* JPRedExpList_hpp */
