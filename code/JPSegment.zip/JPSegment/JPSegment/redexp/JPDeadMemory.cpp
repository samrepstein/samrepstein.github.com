//
//  JPDeadMemory.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/22/24.
//

#include "JPDeadMemory.hpp"
#include "exception.h"
#include "JPRedDatum.hpp"



 JPMappedRedDatum::JPMappedRedDatum(){}
JPMappedRedDatum::JPMappedRedDatum(JPRedDConst *constDat, JPRedDatum *sourceDat, int extraOffset) : constDat(constDat), sourceDat(sourceDat), extraOffset(extraOffset) {}

void JPDeadMemory::ProcessKillRegsOrStack(std::map<int,JPRedDatum*> &endDatums,
                 std::set<JPRedDatum*> &allRedDatums)
{
    for(map<int,JPRedDatum*>::iterator itr = endDatums.begin(); itr != endDatums.end(); )
    {
        int reg = itr->first;
        JPRedDatum *dat = itr->second;
        
        if(dat->GetLocationType()==FromMalloc)
        {
            long execCount = dat->GetAuxData().execCountSource;
            if(this->status.contains(execCount) && this->status[execCount]==Kill)
            {
                itr = endDatums.erase(itr);
                continue;
            }
        }
        else
        {
            if(this->datDatOffMap.contains(dat->GetSource()))
            {
                JPMappedRedDatum mapDat = datDatOffMap[dat->GetSource()];
                if(mapDat.constDat!=nullptr)
                {
                    JPRedDConst *copyConst = new JPRedDConst(mapDat.constDat->value);
                    allRedDatums.erase(dat);
                    free(dat);
                    allRedDatums.insert(copyConst);
                    itr->second = copyConst;
                }
                else if(mapDat.sourceDat!=nullptr)
                {
                    JPRedDVar *var = dynamic_cast<JPRedDVar*>(dat);
                    
                    if(var != nullptr)
                    {
                        var->SetSource(mapDat.sourceDat);
                        var->SetLocationType(mapDat.sourceDat->GetLocationType(),mapDat.sourceDat->GetAuxData());
                        var->offset += mapDat.extraOffset;
                    }
                    else
                    {
                        //Cannot override a const RedDatum with a Var RedDatum
                    }
                }
            }
        }
        
        itr++;
    }
}

JPRedExp* JPDeadMemory::ProcessKillExp(JPRedExp *redExp, std::set<JPRedDatum*> &allRedDatums)
{
    JPRedLWExp *lwExp = dynamic_cast<JPRedLWExp*>(redExp);
    JPRedSWExp *swExp = dynamic_cast<JPRedSWExp*>(redExp);
    JPRedMallocExp * mallocExp = dynamic_cast<JPRedMallocExp*>(redExp);
    JPRedFreeExp *freeExp = dynamic_cast<JPRedFreeExp*>(redExp);
    
    if(mallocExp != nullptr)
    {
        long execCount = mallocExp->GetExecCount();
        if(IsKilled(execCount))
            return nullptr;
        
        return mallocExp;
    }
    
    if(freeExp != nullptr)
    {
        JPRedDVar* dat = freeExp->GetArgDatum();
        
        if(this->datDatOffMap.contains(dat->GetSource()))
        {
            JPMappedRedDatum mappedDatum = datDatOffMap[dat->GetSource()];
            if(mappedDatum.constDat!=nullptr)
            {
                throw new Exception("JPDeadMemory: freeExp cannot have const arg");
            }
            if(mappedDatum.sourceDat!=nullptr)
            {
                dat->SetSource(mappedDatum.sourceDat);
                dat->SetLocationType(mappedDatum.sourceDat->GetLocationType(),mappedDatum.sourceDat->GetAuxData());
                dat->offset += mappedDatum.extraOffset;
            }
        }
        
        if(dat->GetLocationType()!=FromMalloc)
            return freeExp;
        
        long execCount = dat->GetAuxData().execCountSource;
        if(IsKilled(execCount))
            return nullptr;
        return freeExp;
    }
    
    
    if(swExp != nullptr)
    {
        JPRedDVar *addrDat = dynamic_cast<JPRedDVar*>(swExp->GetAddrDatum());
        JPRedDatum *srcDat = swExp->GetSourceDatum();
        
        if(this->datDatOffMap.contains(addrDat->GetSource()))
        {
            JPMappedRedDatum mappedDatum = datDatOffMap[addrDat->GetSource()];
            if(mappedDatum.constDat!=nullptr)
            {
                throw new Exception("JPDeadMemory: freeExp cannot have const arg");
            }
            if(mappedDatum.sourceDat!=nullptr)
            {
                addrDat->SetSource(mappedDatum.sourceDat);
                addrDat->SetLocationType(mappedDatum.sourceDat->GetLocationType(),mappedDatum.sourceDat->GetAuxData());
                addrDat->offset += mappedDatum.extraOffset;
            }
        }

        if(this->datDatOffMap.contains(srcDat->GetSource()))
        {
            JPMappedRedDatum mappedDatum = datDatOffMap[srcDat->GetSource()];
            if(mappedDatum.constDat!=nullptr)
            {
                JPRedDConst *copyConst = new JPRedDConst(mappedDatum.constDat->value);
                allRedDatums.erase(srcDat);
                free(srcDat);
                swExp->SetSourceDatum(copyConst);
                allRedDatums.insert(copyConst);
            }
            else if(mappedDatum.sourceDat!=nullptr)
            {
                JPRedDVar *srcVar = dynamic_cast<JPRedDVar*>(srcDat);
                
                if(srcVar != nullptr)
                {
                    srcVar->SetSource(mappedDatum.sourceDat);
                    srcVar->SetLocationType(mappedDatum.sourceDat->GetLocationType(),mappedDatum.sourceDat->GetAuxData());
                    srcVar->offset += mappedDatum.extraOffset;
                }
                else
                {
                    //Cannot override a const RedDatum with a Var RedDatum
                }
            }
        }
        
        addrDat = dynamic_cast<JPRedDVar*>(swExp->GetAddrDatum());
        srcDat = swExp->GetSourceDatum();
        
        if(addrDat->GetLocationType()!=FromMalloc)
            return swExp;
        
        long execCount = addrDat->GetAuxData().execCountSource;
        
        if(!IsKilled(execCount))
            return swExp;
        
        JPExecCountOffset co(execCount,addrDat->offset);
        this->memory[co] = srcDat;
        return nullptr;
    }
    
    
    if(lwExp != nullptr)
    {
        JPRedDVar *addrDat = dynamic_cast<JPRedDVar*>(lwExp->GetAddrDatum());
        JPRedDatum *destDat = lwExp->GetDestDatum();
        
        if(this->datDatOffMap.contains(addrDat->GetSource()))
        {
            JPMappedRedDatum mappedDatum = datDatOffMap[addrDat->GetSource()];
            if(mappedDatum.constDat!=nullptr)
            {
                JPRedDConst *copyConst = new JPRedDConst(mappedDatum.constDat->value);
                allRedDatums.erase(addrDat);
                free(addrDat);
                allRedDatums.insert(copyConst);
                lwExp->SetAddrDatum(copyConst);
            }
            else if(mappedDatum.sourceDat!=nullptr)
            {
                addrDat->SetSource(mappedDatum.sourceDat);
                addrDat->SetLocationType(mappedDatum.sourceDat->GetLocationType(),mappedDatum.sourceDat->GetAuxData());
                addrDat->offset += mappedDatum.extraOffset;
            }
        }
        
        addrDat = dynamic_cast<JPRedDVar*>(lwExp->GetAddrDatum());
        
        if(addrDat->GetLocationType()!=FromMalloc)
            return lwExp;
        
        long execCount = addrDat->GetAuxData().execCountSource;
        
        if(!IsKilled(execCount))
            return lwExp;
        
        JPExecCountOffset co(execCount,addrDat->offset);
        if(!memory.contains(co))
            throw new Exception("Program reading from unwritten code");
        JPRedDatum *memDat = memory[co];
        if(memDat == nullptr)
            throw new Exception("JPDeadMemory:memory has null datums.");
        
        JPRedDVar *memVar = dynamic_cast<JPRedDVar*>(memDat);
        JPRedDConst *memConst = dynamic_cast<JPRedDConst*>(memDat);
        
        if(memConst!=nullptr)
        {
            JPMappedRedDatum mappedDatum(memConst,nullptr,0);
            datDatOffMap[destDat] = mappedDatum;
        }
        else if(memVar!=nullptr)
        {
            JPMappedRedDatum mappedDatum(nullptr,memVar->GetSource(),memVar->offset);
            datDatOffMap[destDat] = mappedDatum;
        }
        else
            throw new Exception("JPDeadMemory: unknown type");
        
        return nullptr;
    }

    throw new Exception("JPDeadMemory: unknown exp type.");

}



bool JPDeadMemory::IsKilled(long execCount)
{
    if(!status.contains(execCount))
        return false;
    
    return (status[execCount] == Kill);
}

void JPDeadMemory::ClassMallocAddLWExp(JPRedLWExp *exp)
{
    //Do Nothing
}

void JPDeadMemory::ClassMallocAddSWExp(JPRedSWExp *exp)
{
    JPRedDatum *srcDatum = exp->GetSourceDatum();
    
    JPRedDVar *srcVar = dynamic_cast<JPRedDVar*>(srcDatum);
    
    if(srcVar==nullptr)
        return;
    
    if(srcVar->GetLocationType()!=FromMalloc)
        return;

    long sourceEC = srcVar->GetAuxData().execCountSource;
    this->status[sourceEC] = Freeze;
    
    
}

void JPDeadMemory::ClassMallocAddMallocExp(JPRedMallocExp *exp)
{
    JPRedDatum *dat = exp->GetVarDatum();
    long execCount = dat->GetAuxData().execCountSource;
    
    if(status.contains(execCount))
        throw new Exception("JPDeadMemory: malloc execCount already in status.");
    
    status[execCount] = Pot;
}

bool JPDeadMemory::ClassMallocAddFreeExp(JPRedFreeExp *exp)
{
    JPRedDatum *dat = exp->GetArgDatum();
    long execCount = dat->GetAuxData().execCountSource;
 
    if(!status.contains(execCount))
        return false;
    
    if(status[execCount]==Freeze)
        return false;
    
    if(status[execCount]== Kill)
        throw new Exception("JPDeadMemory: tried to free a killed node");
    
    status[execCount]=Kill;
    return true;
}


bool JPDeadMemory::ClassifyMallocRDatums(JPRedExp *redExp)
{
    JPRedLWExp *lwExp = dynamic_cast<JPRedLWExp*>(redExp);
    JPRedSWExp *swExp = dynamic_cast<JPRedSWExp*>(redExp);
    JPRedMallocExp *mallocExp = dynamic_cast<JPRedMallocExp*>(redExp);
    JPRedFreeExp *freeExp = dynamic_cast<JPRedFreeExp*>(redExp);
    
    if(lwExp!=nullptr)
    {
        ClassMallocAddLWExp(lwExp);
        return false;
    }
    if(swExp!=nullptr)
    {
        ClassMallocAddSWExp(swExp);
        return false;
    }
    if(mallocExp!=nullptr)
    {
        ClassMallocAddMallocExp(mallocExp);
        return false;
    }
    if(freeExp!=nullptr)
        return ClassMallocAddFreeExp(freeExp);
    
    throw new  Exception("JPDeadMemory: unknown exp type.");
    
}
