//
//  JPRedExp.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/16/24.
//

#ifndef JPRedExp_hpp
#define JPRedExp_hpp

#include "JPRedDatum.hpp"
#include <stdio.h>
#include <string>

using namespace std;

class JPRedExp
{
    
protected:
    long pc;
    long execCount;
  
public:
    JPRedExp();
    JPRedExp(long pc, long execCount);
    
    long GetPC(){return pc;}
    long GetExecCount(){return execCount;}
    
    void SetPC(long pc){this->pc=pc;}
    void SetExecCount(long execCount){this->execCount=execCount;}
    
    virtual string ToString();
    
};

class JPRedLWExp : public JPRedExp
{
private:
    JPRedDatum *addrDatum;
    JPRedDatum *destDatum;
    
public:
    JPRedLWExp();
    JPRedLWExp(long pc, long execCount, JPRedDatum *addrDatum, JPRedDatum *destDatum);
    
    JPRedDatum *GetAddrDatum(){return addrDatum;}
    JPRedDatum *GetDestDatum(){return destDatum;}
    
    void SetAddrDatum(JPRedDatum *addrDatum){this->addrDatum = addrDatum;}
    void SetDestDatum(JPRedDatum *destDatum){this->destDatum=destDatum;}
    
    virtual string ToString();
};

class JPRedSWExp : public JPRedExp
{
private:
    JPRedDatum *addrDatum;
    JPRedDatum *sourceDatum;
    
public:
    JPRedSWExp();
    JPRedSWExp(long pc, long execCount, JPRedDatum *addrDatum, JPRedDatum *sourceDatum);
   
    JPRedDatum *GetAddrDatum(){return addrDatum;}
    JPRedDatum *GetSourceDatum(){return sourceDatum;}
    
    void SetAddrDatum(JPRedDatum *addrDatum){this->addrDatum = addrDatum;}
    void SetSourceDatum(JPRedDatum *sourceDatum){this->sourceDatum=sourceDatum;}

    virtual string ToString();
};

class JPRedMallocExp : public JPRedExp
{
private:
    JPRedDConst *argDatum;
    JPRedDVar *varDatum;
    
public:
    JPRedMallocExp();
    JPRedMallocExp(long pc, long execCount, JPRedDConst *argDatum, JPRedDVar *varDatum);
    
    JPRedDConst *GetArgDatum(){return argDatum;}
    JPRedDVar *GetVarDatum(){return varDatum;}
    
    void SetArgDatum(JPRedDConst *argDatum){this->argDatum=argDatum;}
    void SetVarDatum(JPRedDVar *varDatum){this->varDatum=varDatum;}
    
    virtual string ToString();
};

class JPRedFreeExp : public JPRedExp
{
private:
    JPRedDVar *argDatum;
    
public:
    JPRedFreeExp();
    JPRedFreeExp(long pc, long execCount, JPRedDVar *argDatum);
    
    JPRedDVar* GetArgDatum(){return argDatum;}
    void SetArgDatum(JPRedDVar *argDatum){this->argDatum=argDatum;}

    virtual string ToString();
};
#endif /* JPRedExp_hpp */
