//
//  JPDeadMemory.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/22/24.
//

#ifndef JPDeadMemory_hpp
#define JPDeadMemory_hpp

#include <set>
#include <map>
#include <stdio.h>

#include "JPRedExp.hpp"

using namespace std;

class JPExecCountOffset
{
public:
    JPExecCountOffset(){}
    JPExecCountOffset(long execCount, int offset) : execCount(execCount), offset(offset) {}
    long execCount=0;
    int offset=0;
};


struct JPRExecCountOffsetCompare
{
   bool operator() (const JPExecCountOffset& lhs, const JPExecCountOffset& rhs) const
   {
       if(lhs.execCount != rhs.execCount)
           return lhs.execCount < rhs.execCount;
       return lhs.offset < rhs.offset;
   }
};


enum JPDMType {Pot,Kill,Freeze};


class JPMappedRedDatum
{
    
public:
    
    JPMappedRedDatum();
    JPMappedRedDatum(JPRedDConst *constDat, JPRedDatum *sourceDat, int extraOffset);
    JPRedDConst *constDat = nullptr;
    JPRedDatum *sourceDat = nullptr;
    int extraOffset = 0;
};

class JPDeadMemory
{
    
private:
    
    map<long,JPDMType> status;
    map<JPExecCountOffset, JPRedDatum*, JPRExecCountOffsetCompare> memory;
    map<JPRedDatum*, JPMappedRedDatum> datDatOffMap;
    
    void ClassMallocAddLWExp(JPRedLWExp *exp);
    void ClassMallocAddSWExp(JPRedSWExp *exp);
    void ClassMallocAddMallocExp(JPRedMallocExp *exp);
    bool ClassMallocAddFreeExp(JPRedFreeExp *exp);
    
public:
    
    bool IsKilled(long execCount);
    
    bool ClassifyMallocRDatums(JPRedExp *redExp); // one
    JPRedExp*  ProcessKillExp(JPRedExp *redExp, std::set<JPRedDatum*> &allRedDatums); // three
    void ProcessKillRegsOrStack(std::map<int,JPRedDatum*> &endDatums,
                         std::set<JPRedDatum*> &allRedDatums);

};

#endif /* JPDeadMemory_hpp */
