//
//  JPRedExpList.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/16/24.
//

#include "JPRedExpList.hpp"
#include "JPDatum.hpp"
#include "JPRedDatum.hpp"
#include "JPExp.hpp"
#include "JPDeadMemory.hpp"
#include "exception.h"

JPRedExpList::JPRedExpList()
{
    spChange=0;
    isSPtoSP=true;
}

JPRedExpList::~JPRedExpList()
{
    for(list<JPRedExp*>::iterator itr = this->redExps.begin(); itr != this->redExps.end(); itr++)
        free(*itr);
    
    for(set<JPRedDatum*>::iterator itr = this->allRedDatums.begin(); itr != this->allRedDatums.end(); itr++)
        free(*itr);
}

void JPRedExpList::KillDeadMemory()
{
    
    bool hasChanged;
    while(true)
    {
        JPDeadMemory deadMemory;
       
        hasChanged = false;
        
        for(list<JPRedExp*>::iterator itr = this->redExps.begin(); itr != this->redExps.end(); itr++)
        {
            hasChanged |= deadMemory.ClassifyMallocRDatums(*itr);
        }
        
        if(!hasChanged)
            break;
        
        for(list<JPRedExp*>::iterator itr = this->redExps.begin(); itr != this->redExps.end(); )
        {
            JPRedExp *redExp = deadMemory.ProcessKillExp(*itr,allRedDatums);
            if(redExp != nullptr)
                 itr++;
            else
            {
                itr = redExps.erase(itr);
            }
         }
   
        hasChanged=false;

        deadMemory.ProcessKillRegsOrStack(this->endRegs, allRedDatums);
        deadMemory.ProcessKillRegsOrStack(this->endStack, allRedDatums);
    }
}

bool JPRedExpList::LookForHangingDatum()
{
    for(std::map<int,JPRedDatum*>::iterator itr=this->initRegs.begin();
        itr!=this->initRegs.end(); itr++)
    {
        if(!itr->second->IsMarked())
            return true;
    }
    
    for(list<JPRedExp*>::iterator itr = this->redExps.begin();
        itr != this->redExps.end(); itr++)
    {
        JPRedLWExp *redLWExp = dynamic_cast<JPRedLWExp*>(*itr);
        
        if(redLWExp!=nullptr)
        {
            if(!redLWExp->GetDestDatum()->IsMarked())
                return true;
            continue;
        }
        
        JPRedMallocExp *mallocExp = dynamic_cast<JPRedMallocExp*>(*itr);
        
        if(mallocExp!=nullptr)
        {
            if(!mallocExp->GetVarDatum()->IsMarked())
                return true;
            continue;
        }
    }
    return false;
}

void JPRedExpList::RemoveUnmarkedRedDatums()
{
    for(set<JPRedDatum*>::iterator itr = this->allRedDatums.begin(); itr != this->allRedDatums.end();)
    {
        if(!(*itr)->IsMarked())
        {
            free(*itr);
            itr = allRedDatums.erase(itr);
        }
        else
            itr++;
    }
}

void JPRedExpList::DebugPrint()
{
    if(!this->initRegs.empty())
    {
        cout << "InitRegs:\n";
        for(map<int,JPRedDatum*>::iterator itr = initRegs.begin(); itr != initRegs.end(); itr++)
            cout << "\t" << itr->first << ": " << itr->second->ToString() << "\n";
        cout << "\n";
    }
    
    if(!this->endRegs.empty())
    {
        cout << "EndRegs:\n";
        for(map<int,JPRedDatum*>::iterator itr = endRegs.begin(); itr != endRegs.end(); itr++)
            cout << "\t" << itr->first << ": " << itr->second->ToString() << "\n";
        cout << "\n";
    }
    
    if(!this->initStack.empty())
    {
        cout << "InitStack:\n";
        for(map<int,JPRedDatum*>::iterator itr = initStack.begin(); itr != initStack.end(); itr++)
            cout << "\t" << itr->first << ": " << itr->second->ToString() << "\n";
        cout << "\n";
    }
  
    if(!this->endStack.empty())
    {
        cout << "EndStack:\n";
        for(map<int,JPRedDatum*>::iterator itr = endStack.begin(); itr != endStack.end(); itr++)
            cout << "\t" << itr->first << ": " << itr->second->ToString() << "\n";
        cout << "\n";
    }
    
    if(!this->redExps.empty())
    {
        cout << "RedExps:\n";
        for(list<JPRedExp*>::iterator itr = this->redExps.begin(); itr != redExps.end(); itr++)
            cout << "\t" << (*itr)->ToString() << "\n";
        cout << "\n";
    }
    cout << "\tUses Stack Pointer:" << this->UsedSP() << "\n";
    cout << "\tSP to SP:" << this->IsSPtoSP() << "\n";
    cout << "\tSP Change:" << this->GetSPChange() << "\n";
    cout << "\tHanging Datums:" << this->LookForHangingDatum() << "\n";
    cout << "\n\n";
}

void JPRedExpList::CreateRedExps(JPExpList &list)
{
    map<JPDatum*,JPRedDatum*> datumLookup;
    for(set<JPDatum*>::iterator itr = list.InitRegDatumsBegin(); itr != list.InitRegDatumsEnd(); itr++)
    {
        if((*itr)->reg==0)
            throw new Exception("JPRedExpList cannot have 0 InitReg.");
     
        if((*itr)->datType==Const)
        {
            JPRedDConst *constRDatum = new JPRedDConst();
            constRDatum->value = (*itr)->value;
            constRDatum->SetSource(constRDatum);
            constRDatum->Mark();
            this->initRegs[(*itr)->reg]=constRDatum;
            datumLookup[(*itr)] = constRDatum;
            allRedDatums.insert(constRDatum);
            
            continue;
        }
   
        if((*itr)->datType==Var || (*itr)->datType==StackVar)
        {
            if((*itr)->datType==StackVar)
            {
                if((*itr)->reg!= STACK_POINTER_REG)
                    throw new Exception("JPRedExpList: StackVar datum must have 29 register");
                
                if((*itr)->value!= 0)
                    throw new Exception("JPRedExpList: StackVar datum must have 0 value");
            }
                
            JPRedDVar *varRDatum = new JPRedDVar();
            varRDatum->SetLocationTypeReg((*itr)->reg);
            varRDatum->offset=0;
            varRDatum->SetSource(varRDatum);
            this->initRegs[(*itr)->reg]=varRDatum;
            datumLookup[(*itr)] = varRDatum;
            allRedDatums.insert(varRDatum);
            
            continue;
        }
        
    }
    
    for(map<int,JPDatum*>::iterator itr = list.StackFirstReadDatumsBegin(); itr != list.StackFirstReadDatumsEnd(); itr++)
    {
        int offset = itr->first;
        JPDatum *dat = itr->second;
        
        if(dat->datType==Const)
        {
            JPRedDConst *constRDatum = new JPRedDConst();
            constRDatum->value = dat->value;
            constRDatum->SetSource(constRDatum);
            this->initStack[offset]=constRDatum;
            datumLookup[dat] = constRDatum;
            allRedDatums.insert(constRDatum);
            
            continue;
        }
        
        if(dat->datType==StackVar)
            throw new Exception("JPRedExpList: Cannot have a StackVar in the StackReadFirst Set.");
        
        if(dat->datType==Var)
        {
            JPRedDVar *varRDatum = new JPRedDVar();
            varRDatum->SetLocationTypeStackOffset(offset);
            varRDatum->offset=0;
            varRDatum->SetSource(varRDatum);
            this->initStack[offset]=varRDatum;
            datumLookup[dat] = varRDatum;
            allRedDatums.insert(varRDatum);
            continue;
        }
    }
            
    for(std::list<JPExp*>::iterator itr = list.ExpsBegin(); itr != list.ExpsEnd(); itr++)
    {
        JPAddSubExp *asExp = dynamic_cast<JPAddSubExp*>(*itr);
        if(asExp != nullptr)
        {
            if(asExp->IsAllConstant())
                continue;
            
            JPDatum *srcDat = asExp->GetSourceVar();
            JPDatum *destDat = asExp->GetDestDat();
            int offset = asExp->GetConstOffset();
            
            if(destDat->datType==Const)
                throw new Exception("JPRedExpList: Cannot have a Const DestDat");
            
            if(!datumLookup.contains(srcDat))
            {
                string s = "JPRedExpList: Cannot find datum in lookup:";
                s.append(srcDat->ToString());
                throw new Exception(s);
            }
            
            JPRedDVar * srcRVar = dynamic_cast<JPRedDVar*>(datumLookup[srcDat]);
            
            if(srcRVar==nullptr)
                throw new Exception("JPRedExpList: Expected Var RedDatum in JPAddSubExp Handler.");
            
            JPRedDVar *destRDat = new JPRedDVar();
            destRDat->offset = srcRVar->offset+offset;
            destRDat->SetSource(srcRVar->GetSource());
            destRDat->SetLocationType(srcRVar->GetLocationType(),srcRVar->GetAuxData());
            allRedDatums.insert(destRDat);
            datumLookup[destDat] = destRDat;
            
            continue;
        }
        
        JPLWExp *lwExp = dynamic_cast<JPLWExp*>(*itr);
        if(lwExp!=nullptr)
        {
            JPDatum *destDat = lwExp->GetDestDat();
            JPDatum *srcDat = lwExp->GetSrcDat();
            int offset = lwExp->GetOffset();

            if(destDat->datType==StackVar)
                    throw new Exception("JPRedExpList: Cannot have a StackVar as the result of a LWExp.");
            
            JPRedLWExp * redLWExp = new JPRedLWExp();
            redLWExp->SetExecCount(lwExp->GetExecCount());
            redLWExp->SetPC(lwExp->GetPC());
            
            if(!datumLookup.contains(srcDat) && srcDat->datType!=Const)
            {
                string s = "JPRedExpList: Non Const Datum not in lookup:";
                s.append(srcDat->ToString());
                throw new Exception(s);
            }
            else if(!datumLookup.contains(srcDat) && srcDat->datType==Const)
            {
                JPRedDConst *srcRDat = new JPRedDConst(srcDat->value+offset);
                srcRDat->Mark();
                datumLookup[srcDat]=srcRDat;
                redLWExp->SetAddrDatum(srcRDat);
                allRedDatums.insert(srcRDat);
            }
            else
            {
                JPRedDatum *srcRDat = datumLookup[srcDat];
                JPRedDConst *constSrc = dynamic_cast<JPRedDConst*>(srcRDat);
                JPRedDVar *varSrc = dynamic_cast<JPRedDVar*>(srcRDat);
                    
                if(constSrc != nullptr)
                {
                    JPRedDConst *constSrc2 = new JPRedDConst(constSrc->value+offset);
                    constSrc2->Mark();
                    redLWExp->SetAddrDatum(constSrc2);
                    
                    allRedDatums.insert(constSrc2);
                }
                else if(varSrc != nullptr)
                {
                    JPRedDVar *varSrc2 = new JPRedDVar(varSrc->offset+offset);
                    varSrc2->SetSource(varSrc->GetSource());
                    varSrc2->SetLocationType(varSrc->GetLocationType(),varSrc->GetAuxData());
                    varSrc2->Mark();
                    redLWExp->SetAddrDatum(varSrc2);
                    allRedDatums.insert(varSrc2);
                }
                else
                {
                    throw new Exception("JPRedExpList: unknown JPRedDatum type.");
                }
            }
            
            if(destDat->datType==Const)
            {
                JPRedDConst *constRDat = new JPRedDConst();
                constRDat->value = destDat->value;
                constRDat->SetSource(nullptr);
                constRDat->Mark();
                redLWExp->SetDestDatum(constRDat);
                datumLookup[destDat]=constRDat;
                allRedDatums.insert(constRDat);
            }
            else
            {
                JPRedDVar *varRDat = new JPRedDVar();
                varRDat->offset = 0;
                varRDat->SetLocationTypeLWExecCountSource(lwExp->GetExecCount());
                varRDat->SetSource(varRDat);
                redLWExp->SetDestDatum(varRDat);
                datumLookup[destDat]=varRDat;
                allRedDatums.insert(varRDat);
            }
            
            this->redExps.push_back(redLWExp);
            continue;
        }
        
        JPSWExp *swExp = dynamic_cast<JPSWExp*>(*itr);
        if(swExp!=nullptr)
        {
            int offset = swExp->GetOffset();
            JPDatum* srcDat = swExp->GetSrcDat();
            JPDatum* destDat = swExp->GetDestDat();
            
            if(destDat->datType==StackVar)
                throw new Exception("JPRedExpList: Cannot have a StackVar as the destination of a SWExp.");
           
            JPRedSWExp *redSWExp = new JPRedSWExp();
            redSWExp->SetPC(swExp->GetPC());
            redSWExp->SetExecCount(swExp->GetExecCount());
                    
            if(!datumLookup.contains(destDat) && destDat->datType!=Const)
            {
                string s = "JPRedExpList: Non Const Datum not in lookup:";
                s.append(destDat->ToString());
                throw new Exception(s);
                
            }
            else if(!datumLookup.contains(destDat) && destDat->datType==Const)
            {
                JPRedDConst *destRConst = new JPRedDConst(destDat->value+offset);
                destRConst->Mark();
                datumLookup[destDat]=destRConst;
                redSWExp->SetAddrDatum(destRConst);
                allRedDatums.insert(destRConst);
            }
            else
            {
                JPRedDatum *destRDat = datumLookup[destDat];
                JPRedDConst *constDest = dynamic_cast<JPRedDConst*>(destRDat);
                JPRedDVar *varDest = dynamic_cast<JPRedDVar*>(destRDat);
                    
                if(constDest != nullptr)
                {
                    JPRedDConst *constDest2 = new JPRedDConst(constDest->value+offset);
                    constDest2->Mark();
                    redSWExp->SetAddrDatum(constDest2);
                    allRedDatums.insert(constDest2);
                }
                else if(varDest != nullptr)
                {
                    JPRedDVar *varDest2 = new JPRedDVar(varDest->offset+offset);
                    varDest2->SetSource(varDest->GetSource());
                    varDest2->SetLocationType(varDest->GetLocationType(),varDest->GetAuxData());
                    varDest2->Mark();
                    redSWExp->SetAddrDatum(varDest2);
                    allRedDatums.insert(varDest2);
                }
                else
                {
                    throw new Exception("JPRedExpList: unknown JPRedDatum type.");
                }
            }
            
            if(srcDat->datType==Const)
            {
                JPRedDConst *constRDat = new JPRedDConst();
                constRDat->value = srcDat->value;
                constRDat->SetSource(nullptr);
                constRDat->Mark();
                redSWExp->SetSourceDatum(constRDat);
                datumLookup[destDat]=constRDat;
                allRedDatums.insert(constRDat);
            }
            else
            {
                if(!datumLookup.contains(srcDat))
                {
                    string s = "JPRedExpList: cannot find SWExp source datum:";
                    s.append(srcDat->ToString());
                    throw new Exception(s);
                }
                JPRedDVar *predVar = dynamic_cast<JPRedDVar*>(datumLookup[srcDat]);
                JPRedDVar *varRDat = new JPRedDVar();
                varRDat->SetSource(predVar->GetSource());
                varRDat->offset = predVar->offset;
                varRDat->SetLocationType(predVar->GetLocationType(),predVar->GetAuxData());
                varRDat->Mark();
                datumLookup[srcDat]=varRDat;
                allRedDatums.insert(varRDat);
                redSWExp->SetSourceDatum(varRDat);
            }
            redExps.push_back(redSWExp);
            
            continue;
        }
        
        JPFreeExp *freeExp = dynamic_cast<JPFreeExp*>(*itr);
        if(freeExp!=nullptr)
        {
            JPDatum *dat = freeExp->GetDat();
            if(dat->datType!=Var)
            {
                string s = "JPRedExpList: JPFreeExp has to have a Var JPDatum:";
                s.append(dat->ToString());
                throw new Exception(s);
            }
            
            if(!datumLookup.contains(dat))
            {
                string s = "JPRedExpList: JPFreeExp does not have JPDatum in lookup:";
                s.append(dat->ToString());
                throw new Exception(s);
            }
            
            JPRedDVar *var = dynamic_cast<JPRedDVar*>(datumLookup[dat]);
            
            if(var == nullptr)
            {
                string s = "JPRedExpList: JPFreeExp does not have JPRedDVar lookup type:";
                s.append(dat->ToString());
                throw new Exception(s);
            }
            
            JPRedDVar *var2 = new JPRedDVar();
            var2->offset = var->offset;
            var2->SetLocationType(var->GetLocationType(), var->GetAuxData());
            var2->SetSource(var->GetSource());
            var2->Mark();
            allRedDatums.insert(var2);
            datumLookup[dat]=var2;
            
            JPRedFreeExp *redFreeExp = new JPRedFreeExp();
            redFreeExp->SetPC(freeExp->GetPC());
            redFreeExp->SetExecCount(freeExp->GetExecCount());
            redFreeExp->SetArgDatum(var2);
            redExps.push_back(redFreeExp);
            
            continue;
        }
        
        JPMallocExp *mallocExp = dynamic_cast<JPMallocExp*>(*itr);
        if(mallocExp != nullptr)
        {
            JPDatum *srcDat = mallocExp->GetSrcDat();
            JPDatum *destDat = mallocExp->GetDestDat();
            
            if(srcDat->datType != Const)
            {
                string s = "JPRedExpList: JPMallocExp source type is not Const:";
                s.append(srcDat->ToString());
                throw new Exception(s);
            }
            
            JPRedMallocExp * redMallocExp = new JPRedMallocExp();
            redMallocExp->SetPC(mallocExp->GetPC());
            redMallocExp->SetExecCount(mallocExp->GetExecCount());
            
            JPRedDConst *constDat = new JPRedDConst();
            constDat->value = srcDat->value;
            constDat->Mark();
            allRedDatums.insert(constDat);
            redMallocExp->SetArgDatum(constDat);
            
            if(destDat->datType != Var)
            {
                string s = "JPRedExpList: JPMallocExp dest type is not Var:";
                s.append(destDat->ToString());
                throw new Exception(s);
            }
            
            JPRedDVar *varDat = new JPRedDVar();
            varDat->SetSource(varDat);
            varDat->offset = 0;
            varDat->SetLocationTypeMallocExecCountSource(mallocExp->GetExecCount());
            allRedDatums.insert(varDat);
            datumLookup[destDat]=varDat;
            redMallocExp->SetVarDatum(varDat);
            
            redExps.push_back(redMallocExp);
            continue;
        }
        
        throw new Exception("JPRedExpList: Unknown JPExp type.");
    }
    
    for(map<int,JPDatum*>::iterator itr = list.LatestDatumBegin(); itr != list.LatestDatumEnd(); itr++)
    {
        int reg = itr->first;
        JPDatum *dat = itr->second;
        
        if(reg==0)
            throw new Exception("JPRedExpList: cannot have 0 register in DatumLookup.");
        
        if(dat->datType == Const)
        {
            JPRedDConst *constRDat = new JPRedDConst();
            constRDat->value=dat->value;
            constRDat->Mark();
            allRedDatums.insert(constRDat);
            this->endRegs[reg]=constRDat;
            continue;
        }
        
        if(!datumLookup.contains(dat))
        {
            string s = "JPRedExpList: DatumLookup does not contain JDatum:";
            s.append(dat->ToString());
            throw new Exception(s);
        }
        
        JPRedDVar *varRDat = dynamic_cast<JPRedDVar*>(datumLookup[dat]);
        if(varRDat==nullptr)
        {
            string s = "JPRedExpList: JPDatum is not mapped to JPRedDVar type:";
            s.append(dat->ToString());
            throw new Exception(s);
        }
        
        JPRedDVar *varRDat2 = new JPRedDVar();
        varRDat2->SetSource(varRDat->GetSource());
        varRDat2->Mark();
        varRDat2->offset=varRDat->offset;
        varRDat2->SetLocationType(varRDat->GetLocationType(), varRDat->GetAuxData());
        this->endRegs[reg]=varRDat2;
    }
    
    for(map<int,JPDatum*>::iterator itr = list.StackDatumsBegin();
        itr != list.StackDatumsEnd(); itr++)
    {
        int offset = itr->first;
        JPDatum* dat = itr->second;
        
        if(dat->datType==Const)
        {
            JPRedDConst *constRDat = new JPRedDConst();
            constRDat->value=dat->value;
            constRDat->Mark();
            allRedDatums.insert(constRDat);
            this->endStack[offset]=constRDat;
            continue;
        }
        
        if(!datumLookup.contains(dat))
        {
            string s = "JPRedExpList: cannot find datum lookup:";
            s.append(dat->ToString());
            throw new Exception(s);
        }
        
        JPRedDVar *varRDat = dynamic_cast<JPRedDVar*>(datumLookup[dat]);
        if(varRDat==nullptr)
        {
            string s = "JPRedExpList: find datum lookup not of type JPRVar:";
            s.append(dat->ToString());
            throw new Exception(s);
        }
        
        JPRedDVar *varRDat2 = new JPRedDVar();
        varRDat2->offset = varRDat->offset;
        varRDat2->SetSource(varRDat->GetSource());
        varRDat2->Mark();
        varRDat2->SetLocationType(varRDat->GetLocationType(),varRDat->GetAuxData());
        allRedDatums.insert(varRDat2);
        
        this->endStack[offset]=varRDat2;
    }
    
    if(initRegs.contains(STACK_POINTER_REG))
    {
        if(!this->endRegs.contains(STACK_POINTER_REG))
            throw new Exception("JPRedExpList: StackPointer in initRegs but not endRegs");

        JPRedDVar *var = dynamic_cast<JPRedDVar*>(endRegs[STACK_POINTER_REG]);
        
        if(var == nullptr)
            throw new Exception("JPRedExpList: StackPointer RedDatum in endRegs not of Var type.");
        
        if(var->GetLocationType()!=Reg)
        {
            this->isSPtoSP=false;
        }
        else
        {
            int reg = var->GetAuxData().reg;
            if(reg != STACK_POINTER_REG)
            {
                isSPtoSP = false;
            }
            else
            {
                isSPtoSP = true;
                spChange = var->offset;
            }
        }
        
    }
}
