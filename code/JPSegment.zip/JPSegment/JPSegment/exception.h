//
//  exception.h
//  JPSegment
//
//  Created by Samuel Epstein on 4/12/24.
//

#ifndef exception_h
#define exception_h

#include <stdexcept>

class Exception : public std::runtime_error
{
    public:
        Exception(std::string const& msg):
            std::runtime_error(msg)
        {}
};

#endif /* exception_h */
