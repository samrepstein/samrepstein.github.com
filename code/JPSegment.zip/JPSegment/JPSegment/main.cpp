//
//  main.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 3/25/24.
//

#include <iostream>
#include "JPInstList.hpp"
#include "JPInst.hpp"
#include "JPExpList.hpp"
#include "JPRedExpList.hpp"

#include <list>
#include <iostream>

using namespace std;

int main(int argc, const char * argv[]) {

    ifstream rfile;
    rfile.open("/Users/samepst/Documents/MIPs/JPSegment/test/dm3.s");
    JPInstList *list = JPInstList::ParseFile(rfile);

    
    
    JPExpList *expList = list->CreateExpList();
    expList->ConstReconcile();
    //expList->DebugPrint();
    
    JPRedExpList redExpList;
    redExpList.CreateRedExps(*expList);
    redExpList.KillDeadMemory();
    redExpList.DebugPrint();
     
    return 0;
}
