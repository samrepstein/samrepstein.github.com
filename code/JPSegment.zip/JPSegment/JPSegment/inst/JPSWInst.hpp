//
//  JPSWInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPSWInst_hpp
#define JPSWInst_hpp

#include <stdio.h>

#include "JPInstHeader.hpp"

class JPSWInst : public JPInst
{
private:
    
    JPVReg rSrcReg;
    JPVReg rDestReg;
    int off;
    
public:
    
    JPSWInst();
    JPSWInst(long pc, long execCount, JPVReg rSrcReg, JPVReg rDestReg, int off);
    
    virtual void DebugPrint();
    
    int GetOff(){return off;}
    JPVReg GetRSrcReg(){return rSrcReg;}
    JPVReg GetRDestReg(){return rDestReg;}
    
    void SetOff(int off){this->off=off;}
    void SetRDestReg(JPVReg rDestReg){this->rDestReg=rDestReg;}
    void SetRSrcReg(JPVReg rSrcReg){this->rSrcReg=rSrcReg;}
    
    
    virtual void PushBack(JPExpList &list);
    
};
#endif /* JPSWInst_hpp */
