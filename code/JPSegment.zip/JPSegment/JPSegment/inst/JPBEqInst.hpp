//
//  JPBEqInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPBEqInst_hpp
#define JPBEqInst_hpp

#include <stdio.h>
#include "JPInstHeader.hpp"


class JPBEqInst : public JPInst
{
private:
    JPVReg reg1;
    JPVReg reg2;
    bool isEquals;
    
public:
    JPBEqInst();
    JPBEqInst(long pc, long execCount, JPVReg reg1, JPVReg reg2, bool isEquals);
    
    virtual void DebugPrint();
    
    JPVReg GetReg1(){return this->reg1;}
    JPVReg GetReg2(){return this->reg2;}
    bool GetIsEquals(){return this->isEquals;}
    
    void SetReg1(JPVReg reg1){this->reg1=reg1;}
    void SetReg2(JPVReg reg2){this->reg2=reg2;}
    void SetIsEqual(bool isEquals){this->isEquals=isEquals;}
    
    void PushBack(JPExpList &list);
};


#endif /* JPBEqInst_hpp */
