//
//  JPSWInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPSWInst.hpp"


JPSWInst::JPSWInst(){}
JPSWInst::JPSWInst(long pc, long execCount, JPVReg rSrcReg, JPVReg rDestReg, int off) : JPInst(pc,execCount), rSrcReg(rSrcReg), rDestReg(rDestReg), off(off) {}

void JPSWInst::DebugPrint()
{
    std::cout << pc;
    std::cout << execCount;
    std::cout << " sw";
    std::cout << " " << rSrcReg.ToString();
    std::cout << " " << off << "(" << rDestReg.ToString() <<")";
    std::cout << "\n";
}

void JPSWInst::PushBack(JPExpList &list)
{
    JPDatum *srcDat = list.GetOrCreateLatestDatum(rSrcReg.reg, execCount, rSrcReg.val, false);
    JPDatum *destDat = list.GetOrCreateLatestDatum(rDestReg.reg, execCount, rDestReg.val, false);
    
    if(destDat->datType==StackVar)
    {
        int offset = destDat->value+this->off;
        list.SetStackDatum(offset, srcDat);
        return;
    }
    
    
    JPSWExp *exp = new JPSWExp(pc, execCount, destDat, srcDat, this->off);
    list.PushBackExp(exp);
}
