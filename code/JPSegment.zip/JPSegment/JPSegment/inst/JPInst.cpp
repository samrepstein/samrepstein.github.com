//
//  JPInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPInst.hpp"

JPInst::JPInst(){}

JPInst::JPInst(long pc, long execCount) : pc(pc), execCount(execCount) {}

void JPInst::DebugPrint()
{
    throw new Exception("Unimplemented DebugPrint function.");
}


void JPInst::PushBack(JPExpList &list)
{
    throw new Exception("Unimplemented PushBack function.");
}
