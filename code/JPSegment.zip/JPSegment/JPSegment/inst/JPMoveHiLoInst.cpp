//
//  JPMoveHiLiInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPMoveHiLoInst.hpp"

JPMoveHiLoInst::JPMoveHiLoInst(){}
JPMoveHiLoInst::JPMoveHiLoInst(long pc, long execCount, bool isHi, int rDest, int val) : JPInst(pc,execCount), isHi(isHi), rDest(rDest), val(val) {}

void JPMoveHiLoInst::DebugPrint()
{
    std::cout << pc;
    std::cout << " " << execCount;
    if(isHi)
        std::cout << " mfhi";
    else
        std::cout << " mflo";
    
    std::cout << " $" << rDest;
    std::cout << " " << val;
    std::cout << "\n";
}


void JPMoveHiLoInst::PushBack(JPExpList &list)
{
    JPDatum *srcReg;
    if(this->isHi)
        srcReg = list.GetOrCreateLatestDatum(HI_REG, execCount, val, true);
    else
        srcReg = list.GetOrCreateLatestDatum(LO_REG, execCount, val, true);
    
    if(srcReg->datType!=Const)
        throw new Exception("MoveHiLo source is not a Const");
    
    JPDatum *destReg = new JPDatum(Const, rDest, execCount, val, IsZeroNotSet);
    list.AddDatum(destReg);
    list.SetLatestDatum(destReg);
    
}

