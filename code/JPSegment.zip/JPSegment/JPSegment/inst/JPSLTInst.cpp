//
//  JPSLTInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPSLTInst.hpp"


JPSLTInst::JPSLTInst(){}
JPSLTInst::JPSLTInst(long pc, long execCount, int rDest, JPVReg rReg1, JPVReg rReg2) : JPInst(pc,execCount), rDest(rDest), rReg1(rReg1), rReg2(rReg2){}


void JPSLTInst::DebugPrint()
{
    std::cout << pc;
    std::cout << " " << execCount;
    std::cout << " slt";
    std::cout << " $" << rDest;
    std::cout << " " << rReg1.ToString();
    std::cout << " " << rReg2.ToString();
    std::cout << "\n";
}

void JPSLTInst::PushBack(JPExpList &list)
{
    JPDatum *src1Dat = list.GetOrCreateLatestDatum(this->rReg1.reg, execCount, this->rReg1.val, true);
    JPDatum *src2Dat = list.GetOrCreateLatestDatum(this->rReg2.reg, execCount, this->rReg2.val, true);
    
    if(src1Dat->datType==StackVar || src2Dat->datType==StackVar)
        throw new Exception("Cannot have StackVar as an SLT Argument");
    
    if(src1Dat->datType==Var)
    {
        src1Dat->datType=Const;
        list.AddConstDatum(src1Dat);
    }
   
    if(src2Dat->datType==Var)
    {
        src2Dat->datType=Const;
        list.AddConstDatum(src2Dat);
    }
    
    JPDatum *resultDat = new JPDatum();
    resultDat->value = src1Dat->value < src2Dat->value ? 1 : 0;
    resultDat->datType = Const;
    resultDat->execCount = execCount;
    resultDat->reg = this->rDest;
    
    list.AddDatum(resultDat);
    list.SetLatestDatum(resultDat);
    
}

