//
//  JPConstInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPConstInst_hpp
#define JPConstInst_hpp

#include <stdio.h>
#include "JPInstHeader.hpp"

enum JPConstInstType
{
    Mult,
    And,
    Or
};

class JPConstInst : public JPInst
{
private:
    JPConstInstType type;
    
    int rDest=0;
    JPVReg rSrc1;
    JPVReg rSrc2;
    
public:
    
    JPConstInst();
    JPConstInst(long pc, long execCount, JPConstInstType type, int rDest, JPVReg rSrc1, JPVReg rSrc2);
    
    virtual void DebugPrint();
    
    void SetType(JPConstInstType type){ this->type = type;}
    void SetRDest(int rDest){this->rDest=rDest;}
    void SetRSrc1(JPVReg rSrc1){this->rSrc1=rSrc1;}
    void SetRSrc2(JPVReg rSrc2){this->rSrc2=rSrc2;}
  
    JPConstInstType GetType(){return this->type;}
    int GetRDest(){return this->rDest;}
    JPVReg GetRSrc1(){return this->rSrc1;}
    JPVReg GetRSrc2(){return this->rSrc2;}
    
    virtual void PushBack(JPExpList &list);

};
#endif /* JPConstInst_hpp */
