//
//  JPSLTInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPSLTInst_hpp
#define JPSLTInst_hpp

#include <stdio.h>
#include "JPInstHeader.hpp"

class JPSLTInst : public JPInst
{
private:
    int rDest;
    JPVReg  rReg1;
    JPVReg rReg2;
    
public:
    JPSLTInst();
    JPSLTInst(long pc, long execCount, int rDest, JPVReg rReg1, JPVReg rReg2);
    
    virtual void DebugPrint();
    
    int GetRDest(){return rDest;}
    JPVReg GetRReg1(){return rReg1;}
    JPVReg GetRReg2(){return rReg2;}
    
    void SetRDest(int rDest){this->rDest=rDest;}
    void SetRReg1(JPVReg rReg1){this->rReg1 = rReg1;}
    void SetRReg2(JPVReg rReg2){this->rReg2= rReg2;}
    
    virtual void PushBack(JPExpList &list);

};

#endif /* JPSLTInst_hpp */
