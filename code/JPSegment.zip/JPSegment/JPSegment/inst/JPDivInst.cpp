//
//  JPDivInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPDivInst.hpp"

JPDivInst::JPDivInst(){}

JPDivInst::JPDivInst(long pc, long execCount, JPVReg rReg1, JPVReg rReg2) : JPInst(pc,execCount), rReg1(rReg1), rReg2(rReg2) {}

void JPDivInst::DebugPrint()
{
    std::cout << pc;
    std::cout << " " << execCount;
    std::cout << " div";
    std::cout << " " << rReg1.ToString();
    std::cout << " " << rReg2.ToString();
    std::cout << "\n";
}

void JPDivInst::PushBack(JPExpList &list)
{
    JPDatum *src1Dat = list.GetOrCreateLatestDatum(this->rReg1.reg, execCount, this->rReg1.val, true);
    JPDatum *src2Dat = list.GetOrCreateLatestDatum(this->rReg2.reg, execCount, this->rReg2.val, true);
    
    if(src1Dat->datType==StackVar || src2Dat->datType==StackVar)
        throw new Exception("Cannot have StackVar as an SLT Argument");
    
    if(src1Dat->datType==Var)
    {
        src1Dat->datType=Const;
        list.AddConstDatum(src1Dat);
    }
   
    if(src2Dat->datType==Var)
    {
        src2Dat->datType=Const;
        list.AddConstDatum(src2Dat);
    }
    
    JPDatum *hiDat = new JPDatum();
    hiDat->datType = Const;
    hiDat->reg = HI_REG;
    hiDat->execCount = execCount;
    hiDat->value = src1Dat->value % src1Dat->value;
    
    list.AddDatum(hiDat);
    list.SetLatestDatum(hiDat);
    
    JPDatum *loDat = new JPDatum();
    loDat->datType = Const;
    loDat->reg = LO_REG;
    loDat->execCount = execCount;
    loDat->value = src1Dat->value / src1Dat->value;
    
    list.AddDatum(loDat);
    list.SetLatestDatum(loDat);
    
}
