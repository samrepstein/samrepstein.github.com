//
//  JPSLLInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/15/24.
//

#ifndef JPSLLInst_hpp
#define JPSLLInst_hpp

#include "JPInst.hpp"
#include <stdio.h>

class JPSLLInst : public JPInst
{
private:
    JPVReg rSrc;
    int rDest;
    int shift;
    
public:
    
    JPSLLInst();
    JPSLLInst(long pc, long execCount, int shift, int rDest, JPVReg rSrc);
    
    int GetRDest(){return rDest;}
    JPVReg GetRSrc(){return rSrc;}
    int GetShift(){return shift;}
    
    void SetShift(int shift){this->shift=shift;}
    void SetRDest(int rDest);
    void SetRSrc(JPVReg rSrc);
    virtual void DebugPrint();
    virtual void PushBack(JPExpList &list);
};

#endif /* JPSLLInst_hpp */
