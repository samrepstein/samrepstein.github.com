//
//  JPParser.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/5/24.
//

#include "JPParser.hpp"
#include <sstream>
//#include <boost/foreach.hpp>
//#include <boost/tokenizer.hpp>

/*
void JPParser::parseFile(ifstream &file){
    /*
     std::string line;
     while (std::getline(infile, line))
     {
         std::istringstream iss(line);
         int a, b;
         if (!(iss >> a >> b)) { break; } // error

         // process pair (a,b)
     }
     
}

void JPParser::test() {
    std::istringstream iss("The\t\t quick \t brown fox");
    auto str = std::string{};

    while (iss >> str) {
        cout << str << "\n";
    }
}*/

std::list<JPInst*>* ParseFile(ifstream &file)
{
    list<JPInst*>* list = new std::list<JPInst*>();
    
     std::string line;
     while (getline(file, line))
     {
         std::istringstream iss(line);
         std::string op;
         int one, two, three, four, five;
         long pc, execCount;
         std::string vline;
         
         iss >> pc;
         iss >> execCount;
         iss >> op;
         
         if(op == "add" || op == "addu")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(two,four);
             JPVReg reg2(three,five);
             list->push_back(new JPAddSubInst(pc,execCount,true,one,reg1,reg2));
         }
         else if(op == "sub" || op == "subu")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(two,four);
             JPVReg reg2(three,five);
             list->push_back(new JPAddSubInst(pc,execCount,false,one,reg1,reg2));
         }
         else if(op == "mul")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(two,four);
             JPVReg reg2(three,five);
             
             list->push_back(new JPConstInst(pc,execCount,Mult,one, reg1, reg2));
        
         }
         else if(op == "and")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(two,four);
             JPVReg reg2(three,five);
             
             list->push_back(new JPConstInst(pc,execCount,And,one, reg1, reg2));
         }
         else if(op == "or")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(two,four);
             JPVReg reg2(three,five);
             
             list->push_back(new JPConstInst(pc,execCount,Or,one, reg1, reg2));
         }
         else if(op == "div")
         {
             iss >> one;
             iss >> two;
             iss >> vline;
             iss >> three;
             iss >> four;
             
             JPVReg reg1(one,three);
             JPVReg reg2(two, four);
             
             list->push_back(new JPDivInst(pc,execCount,reg1,reg2));
         }
         else if(op == "addi")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             
             JPVReg srcReg(two, four);
             
             list->push_back(new JPAddIInst(pc,execCount,three, one, srcReg));
         }
         else if(op == "beq" || op == "bne")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(one,four);
             JPVReg reg2(two,five);
             
             bool isEquals = (op == "beq");
             
             list->push_back(new JPBEqInst(pc,execCount,reg1,reg2,isEquals));
         }
         else if(op == "ori")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             
             JPVReg rSrcReg(two,four);
             
             list->push_back(new JPORIInst(pc,execCount,one,rSrcReg,three));
         }
         else if(op == "lui")
         {
             iss >> one;
             iss >> two;
             
             list->push_back(new JPLoadUIInst(pc,execCount,one, two));
         }
         else if(op== "syscall")
         {
             list->push_back(new JPSyscallInst(pc,execCount));
         }
         else if(op == "lw")
         {
             std::string s;
             iss >> one;
             iss >> s;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             int pos = (int)s.find('(');
             two = std::stoi(s.substr(0,pos+1));
             three = std::stoi(s.substr(pos+1,s.length()-2));
            
             JPVReg srcReg(three,four);
             
             list->push_back(new JPLWInst(pc,execCount,one, srcReg, two, five));
         }
         else if(op == "sw")
         {
             std::string s;
             iss >> one;
             iss >> s;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             int pos = (int)s.find('(');
             two = std::stoi(s.substr(0,pos+1));
             three = std::stoi(s.substr(pos+1,s.length()-2));
            
             JPVReg srcReg(one, four);
             JPVReg destReg(three, five);
             
             list->push_back(new JPSWInst(pc,execCount,srcReg,destReg,two));
         }
         else if(op == "slt")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(two,four);
             JPVReg reg2(three,five);
             
             list->push_back(new JPSLTInst(pc,execCount,one,reg1,reg2));
         }
        else if(op == "div")
        {
            iss >> one;
            iss >> two;
            iss >> vline;
            iss >> three;
            iss >> four;
            
            JPVReg reg1(one,three);
            JPVReg reg2(two,four);
            
            list->push_back(new JPDivInst(pc,execCount,reg1,reg2));
        }
        else if(op == "mfhi" || op == "mflo")
        {
            bool isHi = (op == "mfhi");
            
            iss >> one;
            iss >> vline;
            iss >> two;
            
            list->push_back(new JPMoveHiLoInst(pc,execCount,isHi, one,two));
        }
        else
        {
            //throw exception("Unknown op"+op);
        }
     }
     
    return list;
}

