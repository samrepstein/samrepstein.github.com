//
//  JPLoadIInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPLoadIInst_hpp
#define JPLoadIInst_hpp

#include <stdio.h>

#include "JPInst.hpp"

class JPLoadIInst : public JPInst
{
private:
    int rDest;
    int val;
public:
    JPLoadIInst();
    JPLoadIInst(long pc, long execCount, int rDest, int val);
    
    int getRDest(){return rDest;}
    int getVal(){return val;}
    
    void SetRDest(int rDest){this->rDest=rDest;}
    void SetValue(int val){this->val = val;}
};
#endif /* JPLoadIInst_hpp */
