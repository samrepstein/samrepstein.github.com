//
//  JPADDIInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPADDIInst.hpp"

JPAddIInst::JPAddIInst(){}

JPAddIInst::JPAddIInst(long pc, long execCount, int constant, int rDest, JPVReg rSrc) : JPInst(pc, execCount), constant(constant), rDest(rDest), rSrc(rSrc) {}

void JPAddIInst::DebugPrint()
{
    std::cout << pc;
    std::cout << " " <<  execCount;
    std::cout << " addi";
    std::cout << " $" << rDest;
    std::cout << " " << rSrc.ToString();
    std::cout << " " << constant;
    std::cout << "\n";
}

void JPAddIInst::PushBack(JPExpList &list)
{
    JPDatum* srcDat = list.GetOrCreateLatestDatum(this->rSrc.reg, execCount, this->rSrc.val, false);
    JPDatum* destDat = new JPDatum();
    destDat->reg=this->rDest;
    destDat->value=srcDat->value+this->constant;
    destDat->datType=srcDat->datType;
    JPDatum* zeroDat = new JPDatum(Const, 0, execCount, this->constant, IsZeroNotSet);
    
    list.AddDatum(zeroDat);
    list.AddDatum(destDat);
    list.SetLatestDatum(destDat);
    
    JPAddSubExp *exp = new JPAddSubExp(pc, execCount, destDat, srcDat, zeroDat, true);
                                       
}
