//
//  JPVReg.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/13/24.
//

#include "JPVReg.hpp"

JPVReg::JPVReg() : JPVReg(0,0){}

JPVReg::JPVReg(int reg, int val) : val(val), reg(reg) {}

std::string JPVReg::ToString()
{
    std::string s = "$";
    s.append(std::to_string(reg));
    s.append("(");
    s.append(std::to_string(val));
    s.append(")");
    return s;
}
