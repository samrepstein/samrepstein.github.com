//
//  JPLWInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPLWInst.hpp"

JPLWInst::JPLWInst(){}
JPLWInst::JPLWInst(long pc, long execCount, int rDestReg, JPVReg rSrcReg, int off, int val) : JPInst(pc,execCount), rDestReg(rDestReg), rSrcReg(rSrcReg), off(off), val(val){}

void JPLWInst::DebugPrint()
{
    std::cout << pc;
    std::cout << " " << execCount;
    std::cout << " lw";
    std::cout << " $" << rDestReg;
    std::cout << " " << off << "(" << rSrcReg.ToString() << ")";
    std::cout << " " << val;
    std::cout << "\n";
}

void JPLWInst::PushBack(JPExpList &list)
{
    JPDatum *srcDat = list.GetOrCreateLatestDatum(rSrcReg.reg, execCount, rSrcReg.val, false);
    JPDatum *destDat = list.GetOrCreateLatestDatum(rDestReg, execCount, val, false);
 
    JPLWExp* lwExp = new JPLWExp(pc, execCount, destDat, srcDat, this->off);
}
