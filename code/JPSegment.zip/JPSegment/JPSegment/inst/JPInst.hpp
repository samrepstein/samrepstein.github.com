//
//  JPInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPInst_hpp
#define JPInst_hpp

#include <stdio.h>
#include <string>
#include <iostream>
//#include "JPInstHeader.hpp"
#include "JPExpList.hpp"
#include "exception.h"

class JPInst
{
protected:
    long pc;
    long execCount;
public:
    JPInst();
    JPInst(long pc, long execCount);
    
    long GetPC(){return pc;}
    long GetExecCount(){return execCount;}
    
    void SetPC(long pc){this->pc=pc;}
    void SetExecCount(long execCount){this->execCount=execCount;}
    
    virtual void DebugPrint();
    virtual void PushBack(JPExpList &list);
};
#endif /* JPInst_hpp */
