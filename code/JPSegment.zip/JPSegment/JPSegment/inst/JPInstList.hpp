//
//  JPParser.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/5/24.
//

#ifndef JPParser_hpp
#define JPParser_hpp

#include <stdio.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <list>

#include "JPInst.hpp"
#include "JPAddSubInst.hpp"
#include "JPConstInst.hpp"
#include "JPAddIInst.hpp"
#include "JPBEqInst.hpp"
#include "JPLIInst.hpp"
#include "JPLoadUIInst.hpp"
#include "JPSyscallInst.hpp"
#include "JPLWInst.hpp"
#include "JPSWInst.hpp"
#include "JPSLTInst.hpp"
#include "JPDivInst.hpp"
#include "JPMoveHiLoInst.hpp"
#include "JPORIInst.hpp"
#include "JPSLLInst.hpp"

using namespace std;

//class JPParser {

//public:
//    void parseFile(ifstream &file);
//    void test();
class JPInstList
{
    
private:
    list<JPInst*> instList;
    
public:
    
    static JPInstList* ParseFile(ifstream &file);
    
    void PushBack(JPInst *inst){instList.push_back(inst);}
    void DebugPrint();
    
    JPExpList *CreateExpList();
};

#endif /* JPParser_hpp */
