//
//  JPJRInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/15/24.
//

#ifndef JPJRInst_hpp
#define JPJRInst_hpp

#include "JPInst.hpp"
#include <stdio.h>

class JPJRInst : public JPInst
{
private:
    JPVReg addrReg;
    
public:
    JPJRInst();
    JPJRInst(long pc, long execCount, JPVReg addrReg);
    
    JPVReg GetAddrReg(){return addrReg;}
    void SetAddrReg(JPVReg addrReg);
    
    virtual void DebugPrint();
    virtual void PushBack(JPExpList &list);
};

#endif /* JPJRInst_hpp */
