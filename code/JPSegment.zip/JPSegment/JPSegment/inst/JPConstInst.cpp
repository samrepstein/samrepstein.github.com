//
//  JPConstInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPConstInst.hpp"

JPConstInst::JPConstInst(){}

JPConstInst::JPConstInst(long pc, long execCount, JPConstInstType type, int rDest, JPVReg rSrc1, JPVReg rSrc2) : JPInst(pc, execCount), type(type), rDest(rDest), rSrc1(rSrc1), rSrc2(rSrc2)
{
    
}

void JPConstInst::DebugPrint()
{
    std::string op;
    
    switch(type)
    {
        case Mult:
            op = "mul";
            break;
        case And:
            op = "and";
            break;
        case Or:
            op = "or";
            break;
        default:
    }
    
    std::cout << pc;
    std::cout << " " << execCount;
    std::cout << " " << op;
    std::cout << " $" << rDest;
    std::cout << " " << rSrc1.ToString();
    std::cout << " " << rSrc2.ToString();
    std::cout << "\n";
}

void JPConstInst::PushBack(JPExpList &list)
{
    JPDatum* dat1 = list.GetOrCreateLatestDatum(this->rSrc1.reg, execCount, this->rSrc1.val, true);
    JPDatum* dat2 = list.GetOrCreateLatestDatum(this->rSrc2.reg, execCount, this->rSrc2.val, true);
    if(dat1->datType==StackVar || dat2->datType==StackVar)
    {
        throw Exception("Cannot perform const operation on a StackVar Datum");
    }
    if(dat1->datType==Var)
    {
        dat1->datType=Const;
        list.AddConstDatum(dat1);
    }
    if(dat2->datType==Var)
    {
        dat2->datType=Const;
        list.AddConstDatum(dat2);
    }
    JPDatum *srcDat = new JPDatum();
    switch (this->type) {
        case Mult:
            srcDat->value = dat1->value * dat2->value;
            break;
        case And:
            srcDat->value = dat1->value & dat2->value;
            break;
        case Or:
            srcDat->value = dat1->value | dat2->value;
            break;
        default:
            throw Exception("Unknown Datum Type:");
            break;
    }
    srcDat->datType=Const;
    srcDat->execCount=execCount;
    srcDat->reg=rDest;
    list.AddDatum(srcDat);
    list.SetLatestDatum(srcDat);
    
}
