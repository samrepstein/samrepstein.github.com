//
//  JPLoadIInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPLoadIInst.hpp"


JPLoadIInst::JPLoadIInst(){}

JPLoadIInst::JPLoadIInst(long pc, long execCount, int rDest, int val): JPInst(pc,execCount), rDest(rDest), val(val) {}
