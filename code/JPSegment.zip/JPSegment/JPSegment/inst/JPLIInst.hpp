//
//  JPLIInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPLIInst_hpp
#define JPLIInst_hpp

#include <stdio.h>

#include "JPInst.hpp"

class JPIInst : public JPInst
{
private:
    int val=0;
    int rDest=0;
public:
    JPIInst();
    JPIInst(long pc, long execCount, int val, int rDest);
    
    int GetVal(){return this->val;}
    int GetRDest(){return this->rDest;}
    
    void SetVal(int val){this->val=val;}
    void SetRDest(int rDest){this->rDest=rDest;}
};
#endif /* JPLIInst_hpp */
