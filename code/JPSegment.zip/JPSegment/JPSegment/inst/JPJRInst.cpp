//
//  JPJRInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/15/24.
//

#include "JPJRInst.hpp"


JPJRInst::JPJRInst(long pc, long execCount, JPVReg addrReg) : JPInst(pc, execCount)
{
    SetAddrReg(addrReg);
}


void JPJRInst::SetAddrReg(JPVReg addrReg)
{
    if(addrReg.val==0 || addrReg.reg==0)
        throw new Exception("JPJRInst cannot have zero address Register.");
    
    this->addrReg = addrReg;
}

void JPJRInst::DebugPrint()
{
    std::cout << pc;
    std::cout << " " << execCount;
    std::cout << " jr ";
    std::cout << addrReg.ToString();
    std::cout << "\n";
}

void JPJRInst::PushBack(JPExpList &list)
{
    list.GetOrCreateLatestDatum(this->addrReg.reg, execCount, this->addrReg.val, true);
}
