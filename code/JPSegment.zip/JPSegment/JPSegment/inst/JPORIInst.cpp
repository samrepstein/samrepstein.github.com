//
//  JPORIInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/10/24.
//

#include "JPORIInst.hpp"

JPORIInst::JPORIInst(){}
JPORIInst::JPORIInst(long pc, long execCount, int rDestReg, JPVReg rSrcReg, int imm) : JPInst(pc,execCount), rDestReg(rDestReg), rSrcReg(rSrcReg), imm(imm) {}

void JPORIInst::DebugPrint()
{
    std::cout << pc;
    std::cout << " " << execCount;
    std::cout << " ori";
    std::cout << " $" << rDestReg;
    std::cout << " " << rSrcReg.ToString();
    std::cout << " " << imm;
    std::cout << "\n";
}

void JPORIInst::PushBack(JPExpList &list)
{
    bool useConst = (imm == 0) ? false : true;
    JPDatum *srcReg = list.GetOrCreateLatestDatum(rSrcReg.reg, execCount, rSrcReg.val, useConst);
    
    JPDatum *destReg = new JPDatum();
    destReg->reg = rDestReg;
    destReg->execCount = execCount;
    destReg->datType = srcReg->datType;
    destReg->value = srcReg->value | (0xffff & imm);
    
    list.AddDatum(destReg);
    list.SetLatestDatum(destReg);
    
    if(imm == 0)
    {
        JPDatum *zeroReg = new JPDatum(Const,0,execCount,0,IsZeroNotSet);
        list.AddDatum(zeroReg);
        JPAddSubExp *exp = new JPAddSubExp(pc, execCount, destReg, srcReg, zeroReg, true);
        list.PushBackExp(exp);
    }
}
