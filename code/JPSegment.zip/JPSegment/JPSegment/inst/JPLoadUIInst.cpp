//
//  JPLoadUIInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPLoadUIInst.hpp"


JPLoadUIInst::JPLoadUIInst(){}
JPLoadUIInst::JPLoadUIInst(long pc, long execCount, int rDest, int val) : JPInst(pc,execCount), rDest(rDest), val(val) {}

void JPLoadUIInst::DebugPrint()
{
    std::cout << pc;
    std::cout << " " << execCount;
    std::cout << " lui";
    std::cout << " $" << rDest;
    std::cout << " " << val;
    std::cout << "\n";
}


void JPLoadUIInst::PushBack(JPExpList &list)
{
    JPDatum *resultDat = new JPDatum();
    resultDat->value = (val << 16) & 0xffff0000;
    resultDat->datType = Const;
    resultDat->reg = rDest;
    list.AddDatum(resultDat);
    list.SetLatestDatum(resultDat);
    
}
