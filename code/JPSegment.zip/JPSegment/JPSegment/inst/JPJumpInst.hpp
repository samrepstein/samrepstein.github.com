//
//  JPJumpInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/15/24.
//

#ifndef JPJumpInst_hpp
#define JPJumpInst_hpp
#define RA_REG 31
#include "JPInst.hpp"

#include <stdio.h>

enum JumpType {J, JAL};

class JPJumpInst : public JPInst
{
private:
    JumpType jumpType;
    int address;
public:
    JPJumpInst();
    JPJumpInst(long pc, long execCount, JumpType jumpType, int address);
    
    JumpType GetJumpType(){return jumpType;}
    int GetAddress(){return address;}
    
    void SetJumpType(JumpType jumpType){this->jumpType=jumpType;}
    void SetAddress(int address);
    
    virtual void DebugPrint();
    virtual void PushBack(JPExpList &list);
};

#endif /* JPJumpInst_hpp */
