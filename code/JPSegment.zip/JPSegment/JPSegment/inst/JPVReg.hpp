//
//  JPVReg.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/13/24.
//

#ifndef JPVReg_hpp
#define JPVReg_hpp

#include <stdio.h>
#include <string>
#include "JPExpList.hpp"
#include "JPExp.hpp"
#include "JPInstHeader.hpp"

class JPVReg
{
public:
    JPVReg();
    JPVReg(int reg, int val);
    
    int val;
    int reg;
    
    std::string ToString();
    virtual void PushBack(JPExpList &list);

};

#endif /* JPVReg_hpp */
