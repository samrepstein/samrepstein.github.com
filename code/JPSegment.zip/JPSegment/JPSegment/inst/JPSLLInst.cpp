//
//  JPSLLInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/15/24.
//

#include "JPSLLInst.hpp"


JPSLLInst::JPSLLInst(){}

JPSLLInst::JPSLLInst(long pc, long execCount, int shift, int rDest, JPVReg rSrc)
{
    this->pc=pc;
    this->execCount=execCount;
    SetShift(shift);
    SetRDest(rDest);
    SetRSrc(rSrc);
}

void JPSLLInst::SetRDest(int rDest)
{
    this->rDest=rDest;
}

void JPSLLInst::SetRSrc(JPVReg rSrc)
{
    if(rSrc.IsInvalid())
        throw new Exception("JPSLLInst invalid source register.");
    this->rSrc=rSrc;
}

void JPSLLInst::DebugPrint()
{
    std::cout << pc;
    std::cout << " " << execCount;
    std::cout << " sll";
    std::cout << " $" << rDest;
    std::cout << " " << rSrc.ToString();
    std::cout << " " << shift;
    std::cout << "\n";

}

void JPSLLInst::PushBack(JPExpList &list)
{
    if(this->rSrc.reg==0 && this->rDest==0 && this->shift==0)
    {
        //NOP Operation from SPIM
        return;
    }
    
    bool forceConst = shift == 0 ? false : true;
    JPDatum *srcDatum = list.GetOrCreateLatestDatum(this->rSrc.reg, execCount, this->rSrc.val, forceConst);
    
    int newval=0;
    if (shift >= 0 && shift < 32)
        newval = srcDatum->value << shift;
    else
        newval = srcDatum->value;
    JPDatum *destDatum = new JPDatum(srcDatum->datType,this->rDest,execCount,newval);
    list.AddDatum(destDatum);
    list.SetLatestDatum(destDatum);
    
    if(shift == 0 && srcDatum->datType==Var)
    {
        JPDatum *zeroDatum = new JPDatum(Const,0,0,0);
        JPAddSubExp *exp = new JPAddSubExp(pc, execCount, destDatum, srcDatum, zeroDatum, true);
        list.PushBackExp(exp);
    }
}
   

