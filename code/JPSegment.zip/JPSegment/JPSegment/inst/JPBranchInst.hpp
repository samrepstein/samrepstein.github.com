//
//  JPBranchInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPBranchInst_hpp
#define JPBranchInst_hpp

#include <stdio.h>
#include "JPInst.hpp"

class JPBranchInst : JPInst
{
private:
    JPVReg reg1;
    JPVReg reg2;
public:
    JPBranchInst();
    JPBranchInst(long pc, long execCount, JPVReg reg1, JPVReg reg2);
    
    JPVReg GetJPVReg1(){return reg1;}
    JPVReg GetJPReg2(){return reg2;}
    
    void SetJPReg1(JPVReg reg1){this->reg1=reg1;}
    void SetJPReg2(JPVReg reg2){this->reg2=reg2;}
    
};
#endif /* JPBranchInst_hpp */
