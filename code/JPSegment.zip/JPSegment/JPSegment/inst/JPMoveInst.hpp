//
//  JPMoveInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPMoveInst_hpp
#define JPMoveInst_hpp

#include <stdio.h>
#include "JPInst.hpp"

class JPMoveInst : JPInst
{
private:
    int rDest=0;
    JPVReg rSrc;
public:
    JPMoveInst();
    JPMoveInst(long pc, long execCount, int rDest, JPVReg rSrc);
    
    int GetRDest(){return this->rDest;}
    JPVReg GetRSrc(){return this->rSrc;}
    
    void SetRDest(int rDest){this->rDest=rDest;}
    void SetRSrc(JPVReg rSrc){this->rSrc=rSrc;}
};

#endif /* JPMoveInst_hpp */
