//
//  JPLWInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPLWInst_hpp
#define JPLWInst_hpp

#include <stdio.h>

#include "JPInstHeader.hpp"

class JPLWInst : public JPInst
{
private:
    int rDestReg;
    JPVReg rSrcReg;
    int off;
    int val;
    
public:
    JPLWInst();
    JPLWInst(long pc, long execCount, int rDestReg, JPVReg rSrcReg, int off, int val);
    
    virtual void DebugPrint();
    
    int GetRDestReg(){return rDestReg;}
    JPVReg getRSrcReg(){return rSrcReg;}
    int getOff(){return off;}
    int getVal(){return val;}
    
    void SetRDestReg(int rDestReg){this->rDestReg=rDestReg;}
    void SetRSrcReg(JPVReg rSrcReg){this->rSrcReg=rSrcReg;}
    void SetOff(int off){this->off=off;}
    void SetVal(int val){this->val=val;}
    
    virtual void PushBack(JPExpList &list);
};
#endif /* JPLWInst_hpp */
