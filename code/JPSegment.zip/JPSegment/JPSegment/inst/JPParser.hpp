//
//  JPParser.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/5/24.
//

#ifndef JPParser_hpp
#define JPParser_hpp

#include <stdio.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <list>
#include "JPInstHeader.hpp"

using namespace std;

//class JPParser {

//public:
//    void parseFile(ifstream &file);
//    void test();
    
std::list<JPInst*>* ParseFile(ifstream &file);
//};

#endif /* JPParser_hpp */
