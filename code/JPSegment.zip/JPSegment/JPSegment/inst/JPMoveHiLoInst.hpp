//
//  JPMoveHiLiInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPMoveHiLoInst_hpp
#define JPMoveHiLoInst_hpp

#include <stdio.h>
#include "JPInstHeader.hpp"

class JPMoveHiLoInst : public JPInst
{
private:
    bool isHi;
    int rDest;
    int val;
public:
    JPMoveHiLoInst();
    JPMoveHiLoInst(long pc, long execCount, bool isHi, int rDest, int val);
    
    virtual void DebugPrint();
    
    bool IsHi(){return isHi;}
    int GetRDest(){return rDest;}
    int GetVal(){return val;}
    
    void SetIsHi(bool isHi){this->isHi = isHi;}
    void SetRDest(int rDest){this->rDest = rDest;}
    void SetVal(int val){this->val = val;}
    
    virtual void PushBack(JPExpList &list);

    
};
#endif /* JPMoveHiLoInst_hpp */
