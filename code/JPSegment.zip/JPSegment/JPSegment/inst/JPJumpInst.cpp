//
//  JPJumpInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/15/24.
//

#include "JPJumpInst.hpp"


JPJumpInst::JPJumpInst(long pc, long execCount, JumpType jumpType, int address) : JPInst(pc, execCount)
{
    SetJumpType(jumpType);
    SetAddress(address);
}

void JPJumpInst::SetAddress(int address)
{
    if(address ==0)
        throw new Exception("JPJPump cannot have 0 address");
}

void JPJumpInst::DebugPrint()
{
    std::cout << pc;
    std::cout << " " << execCount;
    if(jumpType==J)
        std::cout << " j";
    else
        std::cout << "jal";
    std::cout << " " << address;
    std::cout << "\n";
}


void JPJumpInst::PushBack(JPExpList &list)
{
    if(jumpType==J)
        return;
    
    list.GetOrCreateLatestDatum(RA_REG, execCount, pc+(long)4, true);
    
}
