//
//  JPAddSubInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPAddSubInst.hpp"

JPAddSubInst::JPAddSubInst(){}
JPAddSubInst::JPAddSubInst(long pc, long execCount, bool isAdd, int rDest, JPVReg rSrc1, JPVReg rSrc2) : JPInst(pc,execCount), isAdd(isAdd), rDest(rDest), rSrc1(rSrc1), rSrc2(rSrc2)
{}

void JPAddSubInst::DebugPrint()
{
    std::string op;
    if(isAdd)
        op = "add";
    else
        op = "sub";
    std::cout << pc;
    std::cout << " " << execCount;
    std::cout << " " << op;
    std::cout << " $" << rDest;
    std::cout << " " << rSrc1.ToString();
    std::cout << " " << rSrc2.ToString();
    std::cout << "\n";
}

void JPAddSubInst::PushBack(JPExpList &list)
{
    JPDatum* dat1 = list.GetOrCreateLatestDatum(this->rSrc1.reg, execCount, this->rSrc1.val, false);
    JPDatum* dat2 = list.GetOrCreateLatestDatum(this->rSrc2.reg, execCount, this->rSrc2.val, false);
    JPDatum* destDat = new JPDatum();
    destDat->reg = this->rDest;
    if(isAdd)
        destDat->value = rSrc1.val + rSrc2.val;
    else
        destDat->value = rSrc1.val - rSrc2.val;
    destDat->execCount = execCount;
    if(dat1->datType==Const && dat2->datType==Const)
    {
        destDat->datType=Const;
    }
    else if(dat1->datType==StackVar)
    {
        dat2->datType=Const;
        list.AddConstDatum(dat2);
        destDat->datType=StackVar;
    }
    else if(dat2->datType==StackVar)
    {
        dat1->datType=Const;
        list.AddConstDatum(dat1);
        destDat->datType=StackVar;
    }
    else
    {
        destDat->datType=Var;
    }
    
    list.SetLatestDatum(destDat);
    list.AddDatum(destDat);
    JPAddSubExp* exp = new JPAddSubExp(pc, execCount, destDat, dat1, dat2, isAdd);
    list.PushBackExp(exp);
}

