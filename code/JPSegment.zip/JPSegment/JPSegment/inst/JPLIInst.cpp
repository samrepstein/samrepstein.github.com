//
//  JPLIInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPLIInst.hpp"


JPIInst::JPIInst(){}
JPIInst::JPIInst(long pc, long execCount, int val, int rDest) : JPInst(pc,execCount), val(val), rDest(rDest) {}
