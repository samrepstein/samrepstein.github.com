//
//  JPAddSubInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPAddSubInst_hpp
#define JPAddSubInst_hpp

#include <stdio.h>
#include "JPInstHeader.hpp"
#include "JPExpList.hpp"
#include "JPExp.hpp"
#include "JPVReg.hpp"


class JPAddSubInst : public JPInst
{
private:
    
    bool isAdd=true;
    int rDest=0;
    JPVReg rSrc1;
    JPVReg rSrc2;
    
public:
    JPAddSubInst();
    JPAddSubInst(long pc, long execCount, bool isAdd, int rDest, JPVReg rSrc1, JPVReg rSrc2);
    
    virtual void DebugPrint();
    
    void SetIsAdd(bool isAdd){this->isAdd = isAdd;}
    void SetRDest(int rDest){this->rDest=rDest;}
    void SetRSrc1(JPVReg rSrc1){this->rSrc1=rSrc1;}
    void SetRSrc2(JPVReg rSrc2){this->rSrc2=rSrc2;}
    
    bool GetIsAdd(){return this->isAdd;}
    int GetRDest(){return this->rDest;}
    JPVReg GetRSrc1(){return this->rSrc1;}
    JPVReg GetRSrc2(){return this->rSrc2;}
    
    virtual void PushBack(JPExpList &list);

};
#endif /* JPAddSubInst_hpp */
