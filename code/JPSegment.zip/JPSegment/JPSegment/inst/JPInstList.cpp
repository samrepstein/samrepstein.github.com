//
//  JPParser.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/5/24.
//

#include "JPInstList.hpp"
#include <sstream>
//#include <boost/foreach.hpp>
//#include <boost/tokenizer.hpp>


JPExpList *JPInstList::CreateExpList()
{
    JPExpList *expList = new JPExpList();
    for(list<JPInst*>::iterator itr = this->instList.begin(); itr != this->instList.end(); itr++)
    {
        (*itr)->PushBack(*expList);
    }
    return expList;
}

void JPInstList::DebugPrint()
{
    for(list<JPInst*>::iterator itr = this->instList.begin(); itr != this->instList.end(); itr++)
    {
        (*itr)->DebugPrint();
    }
}

JPInstList* JPInstList::ParseFile(ifstream &file)
{
    JPInstList *list = new JPInstList();
    
     std::string line;
     while (getline(file, line))
     {
         std::istringstream iss(line);
         std::string op;
         int one, two, three, four, five;
         long pc, execCount;
         std::string vline;
         
         string first;
         
         iss >> first;
         iss >> execCount;
         iss >> op;
         
         if(first.length()==0)
             continue;
         
         
         if(first=="#")
             continue;
         
         pc = std::stoll(first,nullptr,10);
         
         
         if(op == "add" || op == "addu")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(two,four);
             JPVReg reg2(three,five);
             list->PushBack(new JPAddSubInst(pc,execCount,true,one,reg1,reg2));
         }
         else if(op == "sub" || op == "subu")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(two,four);
             JPVReg reg2(three,five);
             list->PushBack(new JPAddSubInst(pc,execCount,false,one,reg1,reg2));
         }
         else if(op == "mul")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(two,four);
             JPVReg reg2(three,five);
             
             list->PushBack(new JPConstInst(pc,execCount,Mult,one, reg1, reg2));
        
         }
         else if(op == "and")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(two,four);
             JPVReg reg2(three,five);
             
             list->PushBack(new JPConstInst(pc,execCount,And,one, reg1, reg2));
         }
         else if(op == "or")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(two,four);
             JPVReg reg2(three,five);
             
             list->PushBack(new JPConstInst(pc,execCount,Or,one, reg1, reg2));
         }
         else if(op == "div")
         {
             iss >> one;
             iss >> two;
             iss >> vline;
             iss >> three;
             iss >> four;
             
             JPVReg reg1(one,three);
             JPVReg reg2(two, four);
             
             list->PushBack(new JPDivInst(pc,execCount,reg1,reg2));
         }
         else if(op == "addi")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             
             JPVReg srcReg(two, four);
             
        
             list->PushBack(new JPAddIInst(pc,execCount,three, one, srcReg));
         }
         else if(op == "beq" || op == "bne")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(one,four);
             JPVReg reg2(two,five);
             
             bool isEquals = (op == "beq");
             
             list->PushBack(new JPBEqInst(pc,execCount,reg1,reg2,isEquals));
         }
         else if(op == "ori")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             
             JPVReg rSrcReg(two,four);
             
             list->PushBack(new JPORIInst(pc,execCount,one,rSrcReg,three));
         }
         else if(op == "lui")
         {
             iss >> one;
             iss >> two;
             
             list->PushBack(new JPLoadUIInst(pc,execCount,one, two));
         }
         else if(op== "syscall")
         {
             list->PushBack(new JPSyscallInst(pc,execCount));
         }
         else if(op == "lw")
         {
             std::string s;
             iss >> one;
             iss >> s;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             int pos = (int)s.find('(');
             two = std::stoi(s.substr(0,pos+1));
             three = std::stoi(s.substr(pos+1,s.length()-2));
            
             JPVReg srcReg(three,four);
             
             list->PushBack(new JPLWInst(pc,execCount,one, srcReg, two, five));
         }
         else if(op == "sw")
         {
             std::string s;
             iss >> one;
             iss >> s;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             int pos = (int)s.find('(');
             two = std::stoi(s.substr(0,pos+1));
             three = std::stoi(s.substr(pos+1,s.length()-2));
            
             JPVReg srcReg(one, four);
             JPVReg destReg(three, five);
             
             list->PushBack(new JPSWInst(pc,execCount,srcReg,destReg,two));
         }
         else if(op == "slt")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             iss >> five;
             
             JPVReg reg1(two,four);
             JPVReg reg2(three,five);
             
             list->PushBack(new JPSLTInst(pc,execCount,one,reg1,reg2));
         }
        else if(op == "div")
        {
            iss >> one;
            iss >> two;
            iss >> vline;
            iss >> three;
            iss >> four;
            
            JPVReg reg1(one,three);
            JPVReg reg2(two,four);
            
            list->PushBack(new JPDivInst(pc,execCount,reg1,reg2));
        }
        else if(op == "mfhi" || op == "mflo")
        {
            bool isHi = (op == "mfhi");
            
            iss >> one;
            iss >> vline;
            iss >> two;
            
            list->PushBack(new JPMoveHiLoInst(pc,execCount,isHi, one,two));
        }
        else if(op == "sll")
         {
             iss >> one;
             iss >> two;
             iss >> three;
             iss >> vline;
             iss >> four;
             
             JPVReg srcReg(two, four);
             
             list->PushBack(new JPSLLInst(pc, execCount, three, one , srcReg));
         }
        else
        {
            //throw exception("Unknown op"+op);
        }
     }
     
    return list;
}

