//
//  JPLoadUIInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPLoadUIInst_hpp
#define JPLoadUIInst_hpp

#include <stdio.h>
#include "JPInstHeader.hpp"

class JPLoadUIInst : public JPInst
{
private:
    int rDest;
    int val;
public:
    JPLoadUIInst();
    JPLoadUIInst(long pc, long execCount, int rDest, int val);
    
    virtual void DebugPrint();
    
    int GetRDest(){return rDest;}
    int GetVal(){return val;}
    
    void SetRDest(int rDest){this->rDest = rDest;}
    void SetVal(int val){this->val=val;}
    
    virtual void PushBack(JPExpList &list);
};

#endif /* JPLoadUIInst_hpp */
