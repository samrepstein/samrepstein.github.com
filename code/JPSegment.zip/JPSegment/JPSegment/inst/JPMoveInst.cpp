//
//  JPMoveInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPMoveInst.hpp"

JPMoveInst::JPMoveInst(){}
JPMoveInst::JPMoveInst(long pc, long execCount, int rDest, JPVReg rSrc) : JPInst(pc,execCount), rDest(rDest), rSrc(rSrc) {}
