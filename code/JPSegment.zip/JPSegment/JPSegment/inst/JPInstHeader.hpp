//
//  JPInstHeader.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPInstHeader_hpp
#define JPInstHeader_hpp

#include <stdio.h>

#include "JPInst.hpp"
#include "JPVReg.hpp"

#include "JPExp.hpp"
#include "JPExpList.hpp"

#include "JPAddSubInst.hpp"
#include "JPConstInst.hpp"
#include "JPAddIInst.hpp"
#include "JPBEqInst.hpp"
#include "JPLIInst.hpp"
#include "JPLoadUIInst.hpp"
#include "JPSyscallInst.hpp"
#include "JPLWInst.hpp"
#include "JPSWInst.hpp"
#include "JPSLTInst.hpp"
#include "JPDivInst.hpp"
#include "JPMoveHiLoInst.hpp"
#include "JPORIInst.hpp"

//#include "JPMoveInst.hpp"
//#include "JPLoadIInst.hpp"
//#include "JPBranchInst.hpp"

#endif /* JPInstHeader_hpp */
