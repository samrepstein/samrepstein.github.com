//
//  JPORIInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/10/24.
//

#ifndef JPORIInst_hpp
#define JPORIInst_hpp

#include <stdio.h>
#include "JPInstHeader.hpp"

class JPORIInst : public JPInst
{
private:
    int rDestReg;
    JPVReg rSrcReg;
    int imm;
public:
    JPORIInst();
    JPORIInst(long pc, long execCount, int rDestReg, JPVReg rSrcReg, int imm);
    
    virtual void DebugPrint();
    
    int GetRDestReg(){return rDestReg;}
    JPVReg GetRSrcReg(){return rSrcReg;}
    int GetImm(){return imm;}
    
    void SetRDestReg(int rDestReg){this->rDestReg=rDestReg;}
    void SetRSrcReg(JPVReg rSrcReg){this->rSrcReg=rSrcReg;}
    void SetImm(int imm){this->imm=imm;}
    
    virtual void PushBack(JPExpList &list);

};
#endif /* JPORIInst_hpp */
