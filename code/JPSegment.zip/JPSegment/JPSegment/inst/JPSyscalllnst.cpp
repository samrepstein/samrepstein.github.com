//
//  JPSysCallnst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPSyscallInst.hpp"

JPSyscallInst::JPSyscallInst(){}
//JPSyscallInst::JPSyscallInst(SyscallType type) : type(type)
//{
//}

void JPSyscallInst::DebugPrint()
{
    std::cout << pc;
    std::cout << " " << execCount;
    std::cout << " syscall";
    std::cout << "\n";
}

 
void JPSyscallInst::PushBack(JPExpList &list)
{
    JPDatum* sysTypeDat = list.GetLatestDatum(SYSCALL_TYPE_REG);
    
    if(sysTypeDat == 0)
        throw new Exception("Syscall has unknown type");
    
    if(sysTypeDat->datType==StackVar)
        throw new Exception("Syscall type cannot be a StackVar");
    
    if(sysTypeDat->isZeroNotSet != IsZeroSet)
        throw new Exception("Syscall type cannot have IsZero type");
    
    if(sysTypeDat->value == SYSCALL_TYPE_MALLOC)
    {
        if(sysTypeDat->datType==Var)
        {
            sysTypeDat->datType=Const;
            list.AddConstDatum(sysTypeDat);
        }
        
        JPDatum *argDat = list.GetLatestDatum(SYSCALL_ARG_REG);
        if(argDat==0)
            throw new Exception("Malloc Syscall has no arg set");
        if(argDat->datType==StackVar)
            throw new Exception("Malloc Syscall has StackVar arg");
        if(argDat->datType==Var)
        {
            argDat->datType = Const;
            list.AddConstDatum(argDat);
        }
        
        JPDatum *resultDat = new JPDatum(Var,SYSCALL_DEST_REG,execCount,0,IsZeroNotSet);
        resultDat->unknownValue = true;
        list.AddDatum(resultDat);
        list.SetLatestDatum(resultDat);
        
        JPMallocExp *mallocExp = new JPMallocExp(pc,execCount,argDat,resultDat);
        list.PushBackExp(mallocExp);
        return;
    }
        
    
    if(sysTypeDat->value == SYSCALL_TYPE_FREE)
    {
        if(sysTypeDat->datType==Var)
        {
            sysTypeDat->datType=Const;
            list.AddConstDatum(sysTypeDat);
        }
        
        JPDatum *argDat = list.GetLatestDatum(SYSCALL_ARG_REG);
        if(argDat==0)
            throw new Exception("Free Syscall has no arg set");
        if(argDat->datType==StackVar)
            throw new Exception("Free Syscall has StackVar arg");
        if(argDat->datType==Const)
            throw new Exception("Free Syscall has Const arg");
 
        JPFreeExp *freeExp = new JPFreeExp(pc,execCount,argDat);
        list.PushBackExp(freeExp);
        return;
    }
    
    string s = "Syscall type is unsupported:";
    s.append(to_string(sysTypeDat->value));
    throw new Exception(s);
}
