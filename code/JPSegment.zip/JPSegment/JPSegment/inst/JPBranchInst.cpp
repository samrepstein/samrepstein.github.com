//
//  JPBranchInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPBranchInst.hpp"


JPBranchInst::JPBranchInst(){}

JPBranchInst::JPBranchInst(long pc, long execCount, JPVReg reg1, JPVReg reg2) : JPInst(pc,execCount), reg1(reg1), reg2(reg2) {}
