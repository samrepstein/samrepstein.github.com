//
//  JPBEqInst.cpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#include "JPBEqInst.hpp"

JPBEqInst::JPBEqInst() {}

JPBEqInst::JPBEqInst(long pc, long execCount, JPVReg reg1, JPVReg reg2, bool isEquals) : JPInst(pc,execCount), reg1(reg1), reg2(reg2), isEquals(isEquals){}

void JPBEqInst::DebugPrint()
{
    std::cout << pc;
    std::cout << " " << execCount;

    if(isEquals)
        std::cout << " beq";
    else
        std::cout << " bne";
    
    std::cout << " " << reg1.ToString();
    std::cout << " " << reg2.ToString();
    std::cout << "\n";
}

void JPBEqInst::PushBack(JPExpList &list)
{
    JPDatum* dat1 = list.GetOrCreateLatestDatum(this->reg1.reg, execCount, this->reg1.val, false);
    JPDatum* dat2 = list.GetOrCreateLatestDatum(this->reg2.reg, execCount, this->reg2.val, false);
    
    if((dat1->reg==0 || dat1->value==0) && dat2->datType == Var)
    {
        dat2->isZeroNotSet = IsZeroSet;
        list.AddIsZeroDatum(dat2);
        
        if(dat1->reg!=0)
        {
            dat1->datType=Const;
            list.AddConstDatum(dat1);
        }
        return;
    }
    
    if((dat2->reg==0 || dat2->value==0) && dat1->datType == Var)
    {
        dat1->isZeroNotSet = IsZeroSet;
        
        if(dat2->reg!=0)
        {
            dat2->datType=Const;
            list.AddConstDatum(dat2);
        }
        return;
    }
    
    dat1->datType=Const;
    dat2->datType=Const;
    list.AddConstDatum(dat1);
    list.AddConstDatum(dat2);
    
    
}

