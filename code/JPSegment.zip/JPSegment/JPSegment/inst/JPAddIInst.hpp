//
//  JPADDIInst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPADDIInst_hpp
#define JPADDIInst_hpp

#include <stdio.h>
#include "JPInstHeader.hpp"

class JPAddIInst : public JPInst
{
private:
    int constant;
    int rDest;
    JPVReg rSrc;
public:
    JPAddIInst();
    JPAddIInst(long pc, long execCount, int constant, int rDest, JPVReg rSrc);
    
    virtual void DebugPrint();
    
    int GetConstant(){return this->constant;}
    int getRDest(){return this->rDest;}
    JPVReg getRSrc(){return this->rSrc;}
    
    void SetConstant(int constant){this->constant=constant;}
    void SetRDest(int rDest){this->rDest=rDest;}
    void SetRSrc(JPVReg rSrc){this->rSrc=rSrc;}
 
    virtual void PushBack(JPExpList &list);

};

#endif /* JPADDIInst_hpp */
