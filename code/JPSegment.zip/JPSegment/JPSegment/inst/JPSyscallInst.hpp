//
//  JPSysCallnst.hpp
//  JPSegment
//
//  Created by Samuel Epstein on 4/9/24.
//

#ifndef JPSyscallInst_hpp
#define JPSyscallInst_hpp

#define SYSCALL_TYPE_REG 2
#define SYSCALL_ARG_REG 4
#define SYSCALL_DEST_REG 2

#define SYSCALL_TYPE_MALLOC 18
#define SYSCALL_TYPE_FREE 19
#define SYSCALL_TYPE_RAND 20
#define SYSCALL_TYPE PRINT_INT 1

#include <stdio.h>
#include "JPInstHeader.hpp"

//enum SyscallType { Rand, Malloc, Free, Print_Int};

class JPSyscallInst : public JPInst
{
private:
    //SyscallType type;
public:
    JPSyscallInst();
    JPSyscallInst(long pc, long execCount) : JPInst(pc,execCount){}
   
    virtual void DebugPrint();
    
    //JPSyscallInst(SyscallType type);
    
    //SyscallType GetType(){return type;}
    //void SetType(SyscallType type){this->type = type;}
  
    virtual void PushBack(JPExpList &list);

};
#endif /* JPSyscallInst_hpp */
